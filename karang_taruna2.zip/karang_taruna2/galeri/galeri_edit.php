<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include __DIR__ . '/../koneksi.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

$query = mysqli_prepare($koneksi, "SELECT * FROM galeri WHERE id = ?");
mysqli_stmt_bind_param($query, "i", $id);
mysqli_stmt_execute($query);
$result = mysqli_stmt_get_result($query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    die("Data galeri tidak ditemukan.");
}

$pesan = "";

if (isset($_POST['update'])) {
    $judul = trim($_POST['judul']);
    $keterangan = trim($_POST['keterangan']);
    $namaFoto = $data['foto'];
    $fotoBaru = false;

    if ($judul === "") {
        $pesan = "Judul harus diisi.";
    } else {
        // Periksa apakah pengguna memilih foto baru
        if (isset($_FILES['foto']) &&
            $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {

            $file = $_FILES['foto'];

            if ($file['error'] !== UPLOAD_ERR_OK) {
                $pesan = "Foto gagal diunggah.";
            } elseif ($file['size'] > 5 * 1024 * 1024) {
                $pesan = "Ukuran foto maksimal 5 MB.";
            } else {
                // Validasi jenis gambar
                $infoGambar = getimagesize($file['tmp_name']);
                $mime = $infoGambar ? $infoGambar['mime'] : '';

                $jenisGambar = [
                    'image/jpeg' => 'jpg',
                    'image/png'  => 'png',
                    'image/gif'  => 'gif',
                    'image/webp' => 'webp'
                ];

                if (!isset($jenisGambar[$mime])) {
                    $pesan = "Gunakan gambar JPG, PNG, GIF, atau WEBP.";
                } else {
                    $ekstensi = $jenisGambar[$mime];
                    $namaFoto = uniqid('foto_', true) . '.' . $ekstensi;

                    $folder = __DIR__ . '/../uploads/';

                    if (!is_dir($folder)) {
                        mkdir($folder, 0755, true);
                    }

                    if (move_uploaded_file(
                        $file['tmp_name'],
                        $folder . $namaFoto
                    )) {
                        $fotoBaru = true;
                    } else {
                        $pesan = "Foto tidak dapat disimpan. Periksa folder uploads.";
                    }
                }
            }
        }

        if ($pesan === "") {
            $sql = "UPDATE galeri
                    SET judul = ?, foto = ?, keterangan = ?
                    WHERE id = ?";

            $stmt = mysqli_prepare($koneksi, $sql);
            mysqli_stmt_bind_param(
                $stmt, "sssi", $judul, $namaFoto, $keterangan, $id
            );

            if (mysqli_stmt_execute($stmt)) {
                // Hapus foto lama hanya jika foto baru berhasil disimpan
                if ($fotoBaru && !empty($data['foto'])) {
                    $fotoLama = __DIR__ . '/../uploads/' . basename($data['foto']);
                    if (is_file($fotoLama)) {
                        unlink($fotoLama);
                    }
                }

                header("Location: galeri.php");
                exit;
            } else {
                if ($fotoBaru) {
                    $fotoGagal = __DIR__ . '/../uploads/' . $namaFoto;
                    if (is_file($fotoGagal)) {
                        unlink($fotoGagal);
                    }
                }
                $pesan = "Gagal memperbarui data galeri.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Galeri</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .preview {
            display: block;
            width: 200px;
            max-width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
            margin: 10px 0;
        }
        .pesan {
            background: #ffe4ec;
            color: #a33e5c;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="container">
    <div class="form-box">
        <h2 class="judul">Edit Galeri</h2>

        <?php if ($pesan !== ""): ?>
            <div class="pesan">
                <?= htmlspecialchars($pesan) ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <label>Judul</label>
            <input
                type="text"
                name="judul"
                value="<?= htmlspecialchars($data['judul']) ?>"
                required
            >

            <label>Foto Saat Ini</label>
            <?php if (!empty($data['foto'])): ?>
                <img
                    id="preview"
                    class="preview"
                    src="../uploads/<?= rawurlencode(basename($data['foto'])) ?>"
                    alt="Foto galeri"
                >
            <?php else: ?>
                <img id="preview" class="preview" alt="Preview foto">
            <?php endif; ?>

            <label>Pilih Foto Baru (opsional)</label>
            <input
                type="file"
                name="foto"
                id="foto"
                accept="image/jpeg,image/png,image/gif,image/webp"
            >
            <small>Kosongkan jika tidak ingin mengganti foto. Maksimal 5 MB.</small>

            <label>Keterangan</label>
            <textarea name="keterangan" rows="5"><?= htmlspecialchars($data['keterangan'] ?? '') ?></textarea>

            <button type="submit" name="update" class="btn">
                Simpan Perubahan
            </button>

            <a href="galeri.php" class="btn">Kembali</a>
        </form>
    </div>
</div>

<script>
document.getElementById('foto').addEventListener('change', function () {
    const file = this.files[0];
    const preview = document.getElementById('preview');

    if (file) {
        preview.src = URL.createObjectURL(file);
    }
});
</script>
</body>
</html>