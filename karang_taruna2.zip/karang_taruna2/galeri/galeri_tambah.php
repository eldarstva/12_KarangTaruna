<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include __DIR__ . '/../koneksi.php';

if (isset($_POST['simpan'])) {

    // =========================
    // AMBIL DATA FORM
    // =========================

    $judul = mysqli_real_escape_string(
        $koneksi,
        $_POST['judul']
    );

    $keterangan = mysqli_real_escape_string(
        $koneksi,
        $_POST['keterangan']
    );


    // =========================
    // CEK FOTO
    // =========================

    if (!isset($_FILES['foto']) || $_FILES['foto']['error'] != 0) {

        echo "<script>
                alert('Silakan pilih foto terlebih dahulu!');
                window.history.back();
              </script>";
        exit;
    }


    // =========================
    // DATA FOTO
    // =========================

    $namaFoto = $_FILES['foto']['name'];
    $tmpFoto = $_FILES['foto']['tmp_name'];
    $ukuranFoto = $_FILES['foto']['size'];


    // =========================
    // CEK EKSTENSI FOTO
    // =========================

    $ekstensi = strtolower(
        pathinfo($namaFoto, PATHINFO_EXTENSION)
    );

    $ekstensiDiizinkan = [
        'jpg',
        'jpeg',
        'png',
        'gif',
        'webp'
    ];


    if (!in_array($ekstensi, $ekstensiDiizinkan)) {

        echo "<script>
                alert('Format foto harus JPG, JPEG, PNG, GIF, atau WEBP!');
                window.history.back();
              </script>";
        exit;
    }


    // =========================
    // BATAS UKURAN 5 MB
    // =========================

    if ($ukuranFoto > 5 * 1024 * 1024) {

        echo "<script>
                alert('Ukuran foto maksimal 5 MB!');
                window.history.back();
              </script>";
        exit;
    }


    // =========================
    // FOLDER UPLOAD
    // =========================

    $folder = __DIR__ . '/../uploads/';


    // Jika folder belum ada
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true);
    }


    // =========================
    // BUAT NAMA FOTO BARU
    // =========================

    $namaFotoBaru = time() . "_" . uniqid() . "." . $ekstensi;


    // =========================
    // UPLOAD FOTO
    // =========================

    $upload = move_uploaded_file(
        $tmpFoto,
        $folder . $namaFotoBaru
    );


    if (!$upload) {

        echo "<script>
                alert('Foto gagal diupload!');
                window.history.back();
              </script>";
        exit;
    }


    // =========================
    // SIMPAN KE DATABASE
    // =========================

    $query = mysqli_query(
        $koneksi,
        "INSERT INTO galeri
        (judul, foto, keterangan)
        VALUES
        ('$judul', '$namaFotoBaru', '$keterangan')"
    );


    if ($query) {

        echo "<script>
                alert('Foto berhasil ditambahkan!');
                window.location='galeri.php';
              </script>";
        exit;

    } else {

        // Jika database gagal,
        // hapus foto yang sudah diupload

        if (file_exists($folder . $namaFotoBaru)) {
            unlink($folder . $namaFotoBaru);
        }

        echo "<script>
                alert('Data gagal disimpan!');
                window.history.back();
              </script>";
        exit;
    }
}

?>


<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tambah Galeri</title>

    <link rel="stylesheet" href="../style.css">

    <style>

        .preview {
            display: none;

            width: 200px;
            height: 140px;

            object-fit: cover;

            margin-top: 10px;

            border-radius: 8px;

            border: 1px solid #ddd;
        }

        .info-file {
            font-size: 12px;

            color: #777;

            margin-top: 5px;
        }

    </style>

</head>


<body>


<div class="container">


    <div class="form-box">


        <h2 class="judul">
            Tambah Galeri
        </h2>


        <form
            method="POST"
            enctype="multipart/form-data"
        >


            <!-- JUDUL -->

            <label>Judul</label>

            <input
                type="text"
                name="judul"
                placeholder="Masukkan judul kegiatan"
                required
            >


            <!-- FOTO -->

            <label>Foto</label>

            <input
                type="file"
                name="foto"
                id="foto"
                accept="image/*"
                required
            >

            <div class="info-file">
                Format: JPG, JPEG, PNG, GIF, WEBP
                <br>
                Maksimal ukuran: 5 MB
            </div>


            <!-- PREVIEW FOTO -->

            <img
                id="preview"
                class="preview"
                alt="Preview Foto"
            >


            <!-- KETERANGAN -->

            <label>Keterangan</label>

            <textarea
                name="keterangan"
                rows="5"
                placeholder="Masukkan keterangan kegiatan..."
            ></textarea>


            <!-- TOMBOL -->

            <button
                type="submit"
                name="simpan"
                class="btn"
            >
                Simpan
            </button>


            <a
                href="galeri.php"
                class="btn"
            >
                Kembali
            </a>


        </form>


    </div>


</div>


<script>

    // =========================
    // PREVIEW FOTO
    // =========================

    document
        .getElementById("foto")
        .addEventListener("change", function() {

            const file = this.files[0];

            const preview =
                document.getElementById("preview");


            if (file) {

                preview.src =
                    URL.createObjectURL(file);

                preview.style.display = "block";

            } else {

                preview.style.display = "none";

            }

        });

</script>


</body>

</html>