<?php
session_start();
require_once __DIR__ . '/../koneksi.php';

// Cek login
if (empty($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

// Ambil data galeri
$query = mysqli_query(
    $koneksi,
    "SELECT * FROM galeri ORDER BY id DESC"
);

if (!$query) {
    die("Query gagal: " . htmlspecialchars(mysqli_error($koneksi)));
}

// Tentukan tautan dashboard berdasarkan role
$role = $_SESSION['role'] ?? '';
$linkDashboard = ($role === 'admin')
    ? '../admin/admin.php'
    : (($role === 'anggota') ? '../anggota/anggota_dashboard.php' : '../login.php');

// Hanya admin yang boleh mengelola galeri
$isAdmin = ($role === 'admin');
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Galeri Kegiatan - Karang Taruna</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --pink: #e7549b;
            --pink-dark: #d63384;
            --pink-light: #fff0f6;
            --pink-soft: #ffe0ed;
            --text: #69475b;
            --white: #ffffff;
            --border: #f5c6dc;
            --orange: #e69a27;
            --red: #dc3545;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: var(--pink-light);
            color: var(--text);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        a {
            text-decoration: none;
        }

        /* =========================
           NAVBAR
        ========================= */
        .navbar {
            width: 100%;
            min-height: 58px;
            padding: 14px 28px;
            background: var(--pink);
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
            flex-wrap: wrap;
            box-shadow: 0 2px 8px rgba(180, 60, 120, 0.12);
        }

        .navbar h2 {
            color: var(--white);
            font-size: 22px;
            font-weight: 700;
            white-space: nowrap;
        }

        .nav-links {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: wrap;
            gap: 8px;
        }

        .nav-links a {
            color: var(--white);
            font-size: 14px;
            font-weight: 700;
            padding: 8px 10px;
            border-radius: 7px;
            transition: background 0.2s ease;
        }

        .nav-links a:hover,
        .nav-links a.active {
            background: rgba(255, 255, 255, 0.2);
        }

        /* =========================
           KONTEN UTAMA
        ========================= */
        .container {
            width: min(100% - 40px, 990px);
            margin: 32px auto 40px;
            flex: 1;
        }

        .judul {
            text-align: center;
            margin-bottom: 28px;
        }

        .judul h1 {
            color: var(--pink-dark);
            font-size: 30px;
            line-height: 1.3;
            margin-bottom: 8px;
        }

        .judul p {
            color: #80536e;
            font-size: 14px;
            line-height: 1.6;
        }

        /* =========================
           TOMBOL TAMBAH
        ========================= */
        .toolbar {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            margin-bottom: 20px;
        }

        .tambah {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            background: var(--pink-dark);
            color: var(--white);
            padding: 11px 17px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 700;
            transition: background 0.2s, transform 0.2s;
        }

        .tambah:hover {
            background: #b9236b;
            transform: translateY(-1px);
        }

        /* =========================
           GRID GALERI
        ========================= */
        .galeri {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
            align-items: stretch;
        }

        .card {
            min-width: 0;
            display: flex;
            flex-direction: column;
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 14px rgba(180, 60, 120, 0.1);
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 18px rgba(180, 60, 120, 0.16);
        }

        .card img {
            display: block;
            width: 100%;
            height: 190px;
            object-fit: cover;
            background: var(--pink-soft);
        }

        .tanpa-foto {
            height: 190px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            gap: 8px;
            background: var(--pink-soft);
            color: #a64d79;
            font-size: 14px;
            text-align: center;
            padding: 15px;
        }

        .ikon-foto {
            font-size: 34px;
        }

        /* =========================
           ISI KARTU
        ========================= */
        .isi-card {
            display: flex;
            flex-direction: column;
            flex: 1;
            padding: 15px;
        }

        .isi-card h3 {
            color: var(--pink-dark);
            font-size: 16px;
            line-height: 1.4;
            margin-bottom: 9px;
            overflow-wrap: anywhere;
        }

        .isi-card p {
            color: var(--text);
            font-size: 13px;
            line-height: 1.6;
            overflow-wrap: anywhere;
        }

        .keterangan-kosong {
            color: #977b8b !important;
        }

        /* =========================
           TOMBOL EDIT DAN HAPUS
        ========================= */
        .aksi {
            display: flex;
            gap: 9px;
            margin-top: auto;
            padding-top: 16px;
        }

        .aksi a {
            flex: 1;
            min-width: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 10px 8px;
            border-radius: 6px;
            color: var(--white);
            font-size: 13px;
            font-weight: 700;
            text-align: center;
            transition: filter 0.2s;
        }

        .aksi a:hover {
            filter: brightness(0.92);
        }

        .edit {
            background: var(--orange);
        }

        .hapus {
            background: var(--red);
        }

        /* =========================
           KONDISI GALERI KOSONG
        ========================= */
        .kosong {
            grid-column: 1 / -1;
            padding: 45px 20px;
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(180, 60, 120, 0.08);
        }

        .kosong .ikon {
            font-size: 42px;
            margin-bottom: 12px;
        }

        .kosong h3 {
            color: var(--pink-dark);
            margin-bottom: 8px;
        }

        .kosong p {
            color: #80536e;
            font-size: 14px;
            line-height: 1.6;
        }

        /* =========================
           FOOTER
        ========================= */
        footer {
            width: 100%;
            margin-top: auto;
            padding: 17px 15px;
            background: var(--pink);
            color: var(--white);
            text-align: center;
            font-size: 13px;
        }

        /* =========================
           TABLET
        ========================= */
        @media (max-width: 760px) {
            .navbar {
                padding: 14px 20px;
                justify-content: center;
            }

            .navbar h2 {
                width: 100%;
                text-align: center;
            }

            .nav-links {
                justify-content: center;
                gap: 5px;
            }

            .nav-links a {
                font-size: 13px;
                padding: 8px;
            }

            .container {
                width: min(100% - 30px, 600px);
                margin-top: 26px;
            }

            .judul h1 {
                font-size: 27px;
            }

            .galeri {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 14px;
            }

            .card img,
            .tanpa-foto {
                height: 165px;
            }

            .isi-card {
                padding: 12px;
            }

            .aksi {
                gap: 7px;
            }

            .aksi a {
                padding: 9px 5px;
                font-size: 12px;
            }
        }

        /* =========================
           HP
        ========================= */
        @media (max-width: 520px) {
            .navbar {
                padding: 15px 12px;
                gap: 10px;
            }

            .navbar h2 {
                font-size: 21px;
            }

            .nav-links {
                width: 100%;
                gap: 4px;
            }

            .nav-links a {
                font-size: 12px;
                padding: 7px;
            }

            .container {
                width: calc(100% - 28px);
                margin: 22px auto 30px;
            }

            .judul {
                margin-bottom: 22px;
            }

            .judul h1 {
                font-size: 25px;
            }

            .toolbar {
                margin-bottom: 16px;
            }

            .tambah {
                width: 100%;
            }

            .galeri {
                grid-template-columns: 1fr;
                gap: 18px;
            }

            .card img,
            .tanpa-foto {
                height: 210px;
            }

            .isi-card {
                padding: 15px;
            }

            .isi-card h3 {
                font-size: 17px;
            }

            .aksi a {
                font-size: 13px;
                padding: 10px;
            }

            footer {
                font-size: 12px;
            }
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar">
        <h2>Karang Taruna</h2>

        <div class="nav-links">
            <a href="../index.php">Beranda</a>
            <a href="../tentang.php">Profil</a>
            <a href="../kegiatan/kegiatan.php">Kegiatan</a>
            <a href="galeri.php" class="active">Galeri</a>
            <a href="<?= htmlspecialchars($linkDashboard, ENT_QUOTES, 'UTF-8'); ?>">
                Dashboard
            </a>
            <a href="../logout.php"
               onclick="return confirm('Yakin ingin logout?');">
                Logout
            </a>
        </div>
    </nav>

    <!-- KONTEN -->
    <main class="container">

        <header class="judul">
            <h1>Galeri Kegiatan</h1>
            <p>Dokumentasi kegiatan Karang Taruna</p>
        </header>

        <!-- Tombol tambah hanya untuk admin -->
        <?php if ($isAdmin): ?>
            <div class="toolbar">
                <a href="galeri_tambah.php" class="tambah">
                    + Tambah Galeri
                </a>
            </div>
        <?php endif; ?>

        <!-- DAFTAR GALERI -->
        <div class="galeri">

            <?php if (mysqli_num_rows($query) > 0): ?>

                <?php while ($data = mysqli_fetch_assoc($query)): ?>

                    <?php
                    $namaFoto = basename($data['foto'] ?? '');
                    $judulFoto = $data['judul'] ?? 'Dokumentasi Kegiatan';
                    $keterangan = $data['keterangan'] ?? '';

                    $lokasiFile = __DIR__ . '/../uploads/' . $namaFoto;
                    $lokasiFoto = '../uploads/' . rawurlencode($namaFoto);

                    $fotoTersedia = (
                        $namaFoto !== '' &&
                        is_file($lokasiFile)
                    );
                    ?>

                    <article class="card">

                        <?php if ($fotoTersedia): ?>

                            <img
                                src="<?= htmlspecialchars($lokasiFoto, ENT_QUOTES, 'UTF-8'); ?>"
                                alt="<?= htmlspecialchars($judulFoto, ENT_QUOTES, 'UTF-8'); ?>"
                                loading="lazy"
                            >

                        <?php else: ?>

                            <div class="tanpa-foto">
                                <span class="ikon-foto">🖼️</span>
                                <span>Foto belum tersedia</span>
                            </div>

                        <?php endif; ?>

                        <div class="isi-card">

                            <h3>
                                <?= htmlspecialchars(
                                    $judulFoto,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </h3>

                            <?php if (trim($keterangan) !== ''): ?>

                                <p>
                                    <?= nl2br(htmlspecialchars(
                                        $keterangan,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    )); ?>
                                </p>

                            <?php else: ?>

                                <p class="keterangan-kosong">Belum ada keterangan.</p>

                            <?php endif; ?>

                            <?php if ($isAdmin): ?>
                                <div class="aksi">

                                    <a
                                        href="galeri_edit.php?id=<?= (int)$data['id']; ?>"
                                        class="edit"
                                    >
                                        Edit
                                    </a>

                                    <a
                                        href="galeri_hapus.php?id=<?= (int)$data['id']; ?>"
                                        class="hapus"
                                        onclick="return confirm('Yakin ingin menghapus galeri ini?');"
                                    >
                                        Hapus
                                    </a>

                                </div>
                            <?php endif; ?>

                        </div>
                    </article>

                <?php endwhile; ?>

            <?php else: ?>

                <div class="kosong">
                    <div class="ikon">🖼️</div>
                    <h3>Galeri Masih Kosong</h3>
                    <p>
                        Belum ada dokumentasi kegiatan yang ditambahkan.
                    </p>
                </div>

            <?php endif; ?>

        </div>

    </main>

    <!-- FOOTER -->
    <footer>
        &copy; <?= date('Y'); ?> Karang Taruna
    </footer>

</body>
</html>
