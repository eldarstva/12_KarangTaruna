<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include __DIR__ . '/../koneksi.php';

$id = $_GET['id'];

mysqli_query(
    $koneksi,
    "DELETE FROM galeri WHERE id='$id'"
);

header("Location: galeri.php");

exit;

?>