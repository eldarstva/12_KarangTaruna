<?php

session_start();

include __DIR__ . '/koneksi.php';

$error = "";


/*
|--------------------------------------------------------------------------
| JIKA SUDAH LOGIN
|--------------------------------------------------------------------------
*/

if (isset($_SESSION['login'])) {

    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/admin.php");
        exit;
    }

    if ($_SESSION['role'] === 'anggota') {
        header("Location: anggota/anggota_dashboard.php");
        exit;
    }
}


/*
|--------------------------------------------------------------------------
| PROSES LOGIN
|--------------------------------------------------------------------------
*/

if (isset($_POST['login'])) {

    $username = trim($_POST['username']);
    $password = $_POST['password'];

    /*
    |--------------------------------------------------------------------------
    | CEK ADMIN
    |--------------------------------------------------------------------------
    */

    $stmtAdmin = mysqli_prepare(
        $koneksi,
        "SELECT * FROM admin WHERE username = ? LIMIT 1"
    );

    mysqli_stmt_bind_param(
        $stmtAdmin,
        "s",
        $username
    );

    mysqli_stmt_execute($stmtAdmin);

    $resultAdmin = mysqli_stmt_get_result($stmtAdmin);

    $admin = mysqli_fetch_assoc($resultAdmin);


    /*
    |--------------------------------------------------------------------------
    | JIKA ADMIN BENAR
    |--------------------------------------------------------------------------
    */

    if (
        $admin &&
        password_verify($password, $admin['password'])
    ) {

        session_regenerate_id(true);

        $_SESSION['login'] = true;
        $_SESSION['role'] = 'admin';
        $_SESSION['username'] = $admin['username'];
        $_SESSION['nama'] = 'Administrator';

        header("Location: admin/admin.php");
        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | CEK ANGGOTA
    |--------------------------------------------------------------------------
    */

    $stmtAnggota = mysqli_prepare(
        $koneksi,
        "SELECT * FROM akun_anggota
         WHERE username = ?
         LIMIT 1"
    );

    mysqli_stmt_bind_param(
        $stmtAnggota,
        "s",
        $username
    );

    mysqli_stmt_execute($stmtAnggota);

    $resultAnggota = mysqli_stmt_get_result($stmtAnggota);

    $anggota = mysqli_fetch_assoc($resultAnggota);


    /*
    |--------------------------------------------------------------------------
    | JIKA ANGGOTA BENAR
    |--------------------------------------------------------------------------
    */

    if (
        $anggota &&
        password_verify($password, $anggota['password'])
    ) {

        session_regenerate_id(true);

        $_SESSION['login'] = true;
        $_SESSION['role'] = 'anggota';
        $_SESSION['username'] = $anggota['username'];
        $_SESSION['nama'] = $anggota['nama'];
        $_SESSION['anggota_id'] = $anggota['id'];

        header("Location: anggota/anggota_dashboard.php");
        exit;
    }


    /*
    |--------------------------------------------------------------------------
    | LOGIN SALAH
    |--------------------------------------------------------------------------
    */

    $error = "Username atau password salah.";
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Login - Karang Taruna Lintang Sakti</title>

    <link
        rel="stylesheet"
        href="style.css"
    >

    <style>

        body {
            min-height: 100vh;
            background:
                linear-gradient(
                    135deg,
                    #fff0f5,
                    #f8d5e1
                );
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-box {
            width: 420px;
            max-width: 92%;
            background: white;
            padding: 35px;
            border-radius: 18px;
            box-shadow:
                0 10px 30px rgba(0,0,0,0.10);
        }

        .login-logo {
            text-align: center;
            font-size: 45px;
            margin-bottom: 5px;
        }

        .login-box h2 {
            text-align: center;
            color: #c96889;
            margin-bottom: 8px;
        }

        .login-subtitle {
            text-align: center;
            color: #888;
            margin-bottom: 25px;
        }

        .login-box label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
            color: #555;
        }

        .login-box input {
            width: 100%;
            padding: 13px;
            margin-bottom: 18px;
            border: 1px solid #ddd;
            border-radius: 8px;
            outline: none;
        }

        .login-box input:focus {
            border-color: #d889a0;
        }

        .login-button {
            width: 100%;
            border: none;
            padding: 13px;
            background: #d889a0;
            color: white;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            font-size: 15px;
        }

        .login-button:hover {
            background: #c76f89;
        }

        .error-box {
            background: #ffe5e8;
            color: #c0394d;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 18px;
            text-align: center;
        }

        .back-home {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #c96889;
            text-decoration: none;
        }

        .back-home:hover {
            text-decoration: underline;
        }

    </style>

</head>

<body>

<div class="login-box">

    <div class="login-logo">
        🌿
    </div>

    <h2>
        Login Karang Taruna
    </h2>

    <p class="login-subtitle">
        Silakan masuk sebagai Admin atau Anggota
    </p>


    <?php if ($error != ""): ?>

        <div class="error-box">

            <?= htmlspecialchars($error); ?>

        </div>

    <?php endif; ?>


    <form method="POST">

        <label>
            Username
        </label>

        <input
            type="text"
            name="username"
            placeholder="Masukkan username"
            required
        >


        <label>
            Password
        </label>

        <input
            type="password"
            name="password"
            placeholder="Masukkan password"
            required
        >


        <button
            type="submit"
            name="login"
            class="login-button"
        >
            🔐 Login
        </button>

    </form>


    <a
        href="index.php"
        class="back-home"
    >
        ← Kembali ke Beranda
    </a>

</div>

</body>

</html>