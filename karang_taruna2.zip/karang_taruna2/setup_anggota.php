<?php

include __DIR__ . '/koneksi.php';


/*
|--------------------------------------------------------------------------
| DATA AKUN ANGGOTA
|--------------------------------------------------------------------------
*/

$nama = "Anggota Karang Taruna";

$username = "anggota1";

$passwordAsli = "anggota123";

$passwordHash = password_hash(
    $passwordAsli,
    PASSWORD_DEFAULT
);


/*
|--------------------------------------------------------------------------
| CEK USERNAME
|--------------------------------------------------------------------------
*/

$cek = mysqli_prepare(
    $koneksi,
    "SELECT id
     FROM akun_anggota
     WHERE username = ?
     LIMIT 1"
);

mysqli_stmt_bind_param(
    $cek,
    "s",
    $username
);

mysqli_stmt_execute($cek);

$result = mysqli_stmt_get_result($cek);


if (mysqli_num_rows($result) > 0) {

    echo "
    <h2>Akun anggota sudah ada.</h2>

    <p>
        Username:
        <b>anggota1</b>
    </p>

    <p>
        Password:
        <b>anggota123</b>
    </p>

    ";

    exit;
}


/*
|--------------------------------------------------------------------------
| BUAT AKUN
|--------------------------------------------------------------------------
*/

$query = mysqli_prepare(
    $koneksi,
    "INSERT INTO akun_anggota
    (nama, username, password)
    VALUES (?, ?, ?)"
);

mysqli_stmt_bind_param(
    $query,
    "sss",
    $nama,
    $username,
    $passwordHash
);


if (mysqli_stmt_execute($query)) {

    echo "

    <div style='
        font-family:Arial;
        max-width:500px;
        margin:60px auto;
        padding:30px;
        background:#fff0f5;
        border-radius:15px;
        text-align:center;
    '>

        <h2 style='color:#c96889;'>
            ✅ Akun Anggota Berhasil Dibuat
        </h2>

        <p>
            Username:
            <b>anggota1</b>
        </p>

        <p>
            Password:
            <b>anggota123</b>
        </p>

        <br>

        <a
            href='login.php'
            style='
                background:#d889a0;
                color:white;
                padding:12px 20px;
                text-decoration:none;
                border-radius:8px;
            '
        >
            Login Sekarang
        </a>

    </div>

    ";

} else {

    echo "
    <h2>Gagal membuat akun anggota.</h2>
    ";

}

?>