<?php
session_start();
require_once __DIR__ . '/koneksi.php';

mysqli_report(MYSQLI_REPORT_OFF);

function h($nilai) {
    return htmlspecialchars((string)($nilai ?? ''), ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| DETEKSI ADMIN
|--------------------------------------------------------------------------
| Sesuaikan nama session jika login.php kamu menggunakan nama berbeda.
*/
$role = strtolower(
    $_SESSION['role']
    ?? $_SESSION['level']
    ?? $_SESSION['akses']
    ?? ''
);

$isAdmin = in_array($role, ['admin', 'administrator'], true);

$pesan = '';
$error = '';

$kegiatanId = (int)(
    $_GET['kegiatan_id']
    ?? $_POST['kegiatan_id']
    ?? 0
);

if (isset($_GET['sukses'])) {
    $pesan = 'Absensi berhasil disimpan.';
}

/*
|--------------------------------------------------------------------------
| SIMPAN ABSENSI
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$isAdmin) {
        $error = 'Hanya admin yang dapat mengisi absensi.';
    } else {
        $statusData = $_POST['status'] ?? [];
        $keteranganData = $_POST['keterangan'] ?? [];

        $cekKegiatan = mysqli_query(
            $koneksi,
            "SELECT id FROM kegiatan WHERE id = $kegiatanId"
        );

        if (
            $kegiatanId < 1 ||
            !$cekKegiatan ||
            mysqli_num_rows($cekKegiatan) === 0
        ) {
            $error = 'Silakan pilih kegiatan terlebih dahulu.';
        } else {
            $sql = "
                INSERT INTO absensi
                    (kegiatan_id, anggota_id, status, keterangan)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    status = VALUES(status),
                    keterangan = VALUES(keterangan)
            ";

            $stmt = mysqli_prepare($koneksi, $sql);

            if (!$stmt) {
                $error = 'Gagal menyiapkan query absensi: '
                       . mysqli_error($koneksi)
                       . '. Pastikan pasangan kegiatan_id dan anggota_id '
                       . 'memiliki UNIQUE KEY.';
            } else {
                $statusValid = [
                    'Hadir',
                    'Izin',
                    'Sakit',
                    'Tidak Hadir'
                ];

                $berhasil = true;

                foreach ($statusData as $idAnggota => $status) {
                    $idAnggota = (int)$idAnggota;
                    $status = trim((string)$status);

                    $keterangan = trim(
                        (string)($keteranganData[$idAnggota] ?? '')
                    );

                    if (
                        $idAnggota < 1 ||
                        !in_array($status, $statusValid, true)
                    ) {
                        continue;
                    }

                    $cekAnggota = mysqli_query(
                        $koneksi,
                        "SELECT id FROM anggota WHERE id = $idAnggota"
                    );

                    if (
                        !$cekAnggota ||
                        mysqli_num_rows($cekAnggota) === 0
                    ) {
                        continue;
                    }

                    mysqli_stmt_bind_param(
                        $stmt,
                        'iiss',
                        $kegiatanId,
                        $idAnggota,
                        $status,
                        $keterangan
                    );

                    if (!mysqli_stmt_execute($stmt)) {
                        $berhasil = false;
                        $error = 'Gagal menyimpan absensi: '
                               . mysqli_stmt_error($stmt);
                        break;
                    }
                }

                mysqli_stmt_close($stmt);

                if ($berhasil) {
                    header(
                        'Location: absensi.php?kegiatan_id='
                        . $kegiatanId . '&sukses=1'
                    );
                    exit;
                }
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| AMBIL DAFTAR KEGIATAN
|--------------------------------------------------------------------------
| Kode ini menggunakan kolom nama_kegiatan dan tanggal.
*/
$daftarKegiatan = mysqli_query(
    $koneksi,
    "SELECT id, nama_kegiatan, tanggal
     FROM kegiatan
     ORDER BY tanggal DESC, id DESC"
);

if (!$daftarKegiatan) {
    $error = 'Gagal membaca data kegiatan. Periksa apakah tabel kegiatan '
           . 'memiliki kolom nama_kegiatan dan tanggal. Detail: '
           . mysqli_error($koneksi);
}

/*
|--------------------------------------------------------------------------
| AMBIL SELURUH ANGGOTA DAN STATUS ABSENSI
|--------------------------------------------------------------------------
*/
$dataAnggota = false;

if ($kegiatanId > 0) {
    $sqlAnggota = "
        SELECT
            a.id,
            a.nama,
            a.jabatan,
            a.jenis_kelamin,
            a.alamat,
            a.no_hp,
            ab.status,
            ab.keterangan,
            ab.tanggal_input
        FROM anggota a
        LEFT JOIN absensi ab
            ON ab.anggota_id = a.id
            AND ab.kegiatan_id = ?
        ORDER BY a.id ASC
    ";

    $stmtData = mysqli_prepare($koneksi, $sqlAnggota);

    if ($stmtData) {
        mysqli_stmt_bind_param($stmtData, 'i', $kegiatanId);
        mysqli_stmt_execute($stmtData);
        $dataAnggota = mysqli_stmt_get_result($stmtData);
    } else {
        $error = 'Gagal mengambil data absensi: '
               . mysqli_error($koneksi);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Absensi Anggota | Karang Taruna Lintang Sakti</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #fff5f8;
            color: #543747;
        }

        .container {
            width: 95%;
            max-width: 1400px;
            margin: 25px auto;
        }

        .header {
            padding: 25px;
            margin-bottom: 18px;
            border-radius: 16px;
            background: linear-gradient(135deg, #e987ad, #f5b7ce);
            color: white;
            box-shadow: 0 5px 15px #d68ca833;
        }

        .header h1 {
            margin: 0 0 8px;
            font-size: 27px;
        }

        .header p {
            margin: 0;
            font-size: 14px;
        }

        .navigasi {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 20px;
        }

        .btn-nav {
            display: inline-block;
            padding: 11px 17px;
            border-radius: 9px;
            background: #df78a0;
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: 0.2s;
        }

        .btn-nav:hover {
            background: #c95783;
        }

        .btn-beranda {
            background: #f8d5e3;
            color: #743d56;
        }

        .btn-beranda:hover {
            background: #f1b9d0;
        }

        .panel {
            padding: 22px;
            margin-bottom: 20px;
            border-radius: 15px;
            background: white;
            box-shadow: 0 4px 16px #dba5b51c;
        }

        .panel h2 {
            margin-top: 0;
            color: #a74f76;
            font-size: 21px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        select,
        input[type="text"] {
            width: 100%;
            min-width: 130px;
            padding: 10px 12px;
            border: 1px solid #edc3d2;
            border-radius: 8px;
            background: #fffafd;
            color: #543747;
            font-family: inherit;
        }

        select:focus,
        input[type="text"]:focus {
            outline: 2px solid #f5b7ce;
            border-color: #df78a0;
        }

        .btn {
            display: inline-block;
            margin-top: 12px;
            padding: 11px 18px;
            border: none;
            border-radius: 8px;
            background: #df78a0;
            color: white;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
        }

        .btn:hover {
            background: #c95783;
        }

        .table-wrap {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 1000px;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px 10px;
            border-bottom: 1px solid #f4dce5;
            text-align: left;
            vertical-align: middle;
            font-size: 14px;
        }

        th {
            background: #fbe2eb;
            color: #773b56;
            white-space: nowrap;
        }

        tbody tr:hover {
            background: #fff8fb;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
        }

        .hadir {
            background: #d9f5e4;
            color: #217446;
        }

        .izin {
            background: #fff0c9;
            color: #8c6500;
        }

        .sakit {
            background: #dcecff;
            color: #245a99;
        }

        .tidak-hadir {
            background: #ffe0e0;
            color: #a52e2e;
        }

        .belum {
            background: #eeeeee;
            color: #666666;
        }

        .alert {
            padding: 13px 16px;
            margin-bottom: 16px;
            border-radius: 9px;
        }

        .success {
            background: #e1f7e9;
            color: #24683b;
        }

        .danger {
            background: #ffe4e4;
            color: #922f2f;
            overflow-wrap: anywhere;
        }

        .info {
            padding: 12px 14px;
            margin-bottom: 16px;
            border-radius: 8px;
            background: #fff0f6;
            color: #84425e;
        }

        .kolom-aksi {
            min-width: 190px;
        }

        .kolom-aksi input {
            margin-top: 8px;
        }

        .kosong {
            padding: 22px;
            text-align: center;
            color: #906b7b;
        }

        @media (max-width: 600px) {
            .container {
                width: 94%;
                margin: 15px auto;
            }

            .header,
            .panel {
                padding: 16px;
            }

            .header h1 {
                font-size: 22px;
            }

            .panel h2 {
                font-size: 18px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <div class="header">
        <h1>Absensi Anggota</h1>
        <p>Karang Taruna Lintang Sakti</p>
    </div>

    <?php
$halamanDashboard = $isAdmin
    ? 'admin/admin.php'
    : 'anggota/anggota_dashboard.php';
?>

<div class="navigasi">
    <a href="<?= h($halamanDashboard) ?>" class="btn-nav">
        &#8592; Dashboard
    </a>

    <a href="index.php" class="btn-nav btn-beranda">
        &#8962; Beranda
    </a>
</div>

    <?php if ($pesan !== ''): ?>
        <div class="alert success">
            <?= h($pesan) ?>
        </div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="alert danger">
            <?= h($error) ?>
        </div>
    <?php endif; ?>

    <div class="panel">
        <form method="GET" action="absensi.php">
            <label for="kegiatan_id">Pilih Kegiatan</label>

            <select name="kegiatan_id" id="kegiatan_id" required>
                <option value="">-- Pilih Kegiatan --</option>

                <?php if ($daftarKegiatan): ?>
                    <?php while ($k = mysqli_fetch_assoc($daftarKegiatan)): ?>
                        <option
                            value="<?= (int)$k['id'] ?>"
                            <?= (int)$k['id'] === $kegiatanId
                                ? 'selected' : '' ?>
                        >
                            <?= h($k['nama_kegiatan']) ?>
                            -
                            <?= !empty($k['tanggal'])
                                ? h(date(
                                    'd-m-Y',
                                    strtotime($k['tanggal'])
                                ))
                                : 'Tanggal belum tersedia' ?>
                        </option>
                    <?php endwhile; ?>
                <?php endif; ?>
            </select>

            <button type="submit" class="btn">
                Tampilkan Absensi
            </button>
        </form>
    </div>

    <?php if ($kegiatanId > 0 && $dataAnggota): ?>

        <div class="panel">
            <h2>Daftar Kehadiran Anggota</h2>

            <?php if ($isAdmin): ?>
                <div class="info">
                    Admin dapat mengisi atau memperbarui status kehadiran
                    anggota, kemudian menekan tombol Simpan Absensi.
                </div>

                <form method="POST" action="absensi.php">
                    <input
                        type="hidden"
                        name="kegiatan_id"
                        value="<?= $kegiatanId ?>"
                    >
            <?php else: ?>
                <div class="info">
                    Halaman ini menampilkan data absensi yang diinput admin.
                    Anggota hanya dapat melihat data dan tidak bisa mengubahnya.
                </div>
            <?php endif; ?>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama Anggota</th>
                            <th>Jabatan</th>
                            <th>Jenis Kelamin</th>
                            <th>Alamat</th>
                            <th>No. HP</th>
                            <th>Status Kehadiran</th>
                            <th>Keterangan</th>

                            <?php if ($isAdmin): ?>
                                <th>Ubah Absensi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>

                    <tbody>
                    <?php
                    $no = 1;

                    while ($a = mysqli_fetch_assoc($dataAnggota)):
                        $status = $a['status'] ?: 'Belum Diabsen';
                        $kelas = 'belum';

                        if ($status === 'Hadir') {
                            $kelas = 'hadir';
                        } elseif ($status === 'Izin') {
                            $kelas = 'izin';
                        } elseif ($status === 'Sakit') {
                            $kelas = 'sakit';
                        } elseif ($status === 'Tidak Hadir') {
                            $kelas = 'tidak-hadir';
                        }
                    ?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= h($a['nama']) ?></td>
                            <td><?= h($a['jabatan']) ?></td>
                            <td><?= h($a['jenis_kelamin']) ?></td>
                            <td><?= h($a['alamat']) ?></td>
                            <td><?= h($a['no_hp']) ?></td>

                            <td>
                                <span class="status <?= h($kelas) ?>">
                                    <?= h($status) ?>
                                </span>
                            </td>

                            <td>
                                <?= h($a['keterangan'] ?: '-') ?>
                            </td>

                            <?php if ($isAdmin): ?>
                                <td class="kolom-aksi">
                                    <select
                                        name="status[<?= (int)$a['id'] ?>]"
                                        aria-label="Status <?= h($a['nama']) ?>"
                                        required
                                    >
                                        <?php
                                        $pilihanStatus = [
                                            'Hadir',
                                            'Izin',
                                            'Sakit',
                                            'Tidak Hadir'
                                        ];
                                        ?>

                                        <?php foreach (
                                            $pilihanStatus as $pilihan
                                        ): ?>
                                            <option
                                                value="<?= h($pilihan) ?>"
                                                <?= $a['status'] === $pilihan
                                                    ? 'selected' : '' ?>
                                            >
                                                <?= h($pilihan) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>

                                    <input
                                        type="text"
                                        name="keterangan[<?= (int)$a['id'] ?>]"
                                        value="<?= h($a['keterangan']) ?>"
                                        placeholder="Keterangan (opsional)"
                                    >
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($isAdmin): ?>
                <button type="submit" class="btn">
                    Simpan Absensi
                </button>
                </form>
            <?php endif; ?>
        </div>

    <?php elseif ($kegiatanId === 0): ?>

        <div class="panel kosong">
            Pilih kegiatan terlebih dahulu untuk melihat daftar absensi.
        </div>

    <?php endif; ?>

</div>
</body>
</html>
