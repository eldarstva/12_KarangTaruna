
<?php
session_start();
require_once __DIR__ . '/koneksi.php';

// Status login
$sudahLogin = !empty($_SESSION['login']);
$role = $_SESSION['role'] ?? '';
$nama = $_SESSION['nama'] ?? $_SESSION['username'] ?? 'Pengguna';

$linkDashboard = 'login.php';

if ($sudahLogin && $role === 'admin') {
    $linkDashboard = 'admin/admin.php';
} elseif ($sudahLogin && $role === 'anggota') {
    $linkDashboard = 'anggota/anggota_dashboard.php';
}

// Ambil 3 kegiatan terbaru
$queryKegiatan = mysqli_query(
    $koneksi,
    "SELECT id, nama_kegiatan, tanggal, lokasi, deskripsi
     FROM kegiatan
     ORDER BY tanggal DESC
     LIMIT 3"
);

// Ambil 3 foto galeri terbaru
$queryGaleri = mysqli_query(
    $koneksi,
    "SELECT id, foto, judul, keterangan
     FROM galeri
     ORDER BY id DESC
     LIMIT 3"
);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Beranda | Karang Taruna Lintang Sakti</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #fff8fb;
            color: #40363b;
            line-height: 1.7;
            min-height: 100vh;
        }

        a {
            text-decoration: none;
        }

        /* =========================
           NAVBAR
        ========================= */
        .navbar {
            position: sticky;
            top: 0;
            z-index: 100;
            background: #e99ab3;
            padding: 15px 6%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            box-shadow: 0 3px 15px #7d385010;
        }

        .brand {
            color: #fff;
            font-size: 19px;
            font-weight: 800;
            white-space: nowrap;
        }

        .menu {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 20px;
        }

        .menu a {
            color: #fff;
            font-size: 14px;
            font-weight: 700;
            transition: color 0.2s;
        }

        .menu a:hover {
            color: #a94367;
        }

        .menu .menu-login {
            background: #c65f83;
            color: #fff;
            padding: 9px 16px;
            border-radius: 9px;
        }

        .menu .menu-login:hover {
            background: #a94367;
            color: #fff;
        }

        /* =========================
           HERO / BERANDA UTAMA
        ========================= */
        .hero {
            padding: 90px 7%;
            background: linear-gradient(135deg, #fff0f5, #f5c7d8);
        }

        .hero-inner {
            max-width: 1050px;
            margin: auto;
            text-align: center;
        }

        .label {
            display: inline-block;
            padding: 7px 14px;
            border-radius: 30px;
            background: #ffffffb8;
            color: #a44366;
            font-size: 13px;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .hero h1 {
            color: #a94367;
            font-size: clamp(30px, 5vw, 48px);
            line-height: 1.2;
            margin-bottom: 20px;
        }

        .hero p {
            max-width: 720px;
            margin: 0 auto 28px;
            color: #634b55;
        }

        /* =========================
           TOMBOL
        ========================= */
        .button {
            display: inline-block;
            padding: 12px 20px;
            margin: 5px;
            border-radius: 9px;
            font-weight: 700;
            transition: 0.2s;
            text-align: center;
        }

        .button-primary {
            background: #c65f83;
            color: #fff;
        }

        .button-primary:hover {
            background: #a94367;
            transform: translateY(-2px);
        }

        .button-secondary {
            background: #fff;
            color: #a94367;
            border: 1px solid #e7afc3;
        }

        .button-secondary:hover {
            background: #fff0f5;
            transform: translateY(-2px);
        }

        /* =========================
           SECTION
        ========================= */
        .section {
            padding: 60px 7%;
        }

        .section-soft {
            background: #fff0f5;
        }

        .section-heading {
            text-align: center;
            max-width: 700px;
            margin: 0 auto 32px;
        }

        .section-heading h2 {
            color: #a94367;
            font-size: 28px;
            margin-bottom: 8px;
        }

        .section-heading p {
            color: #78666e;
        }

        /* =========================
           KARTU KEGIATAN DAN GALERI
        ========================= */
        .cards {
            max-width: 1100px;
            margin: auto;
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 22px;
            align-items: stretch;
        }

        .card {
            min-width: 0;
            background: #fff;
            border: 1px solid #f2dce5;
            border-radius: 16px;
            padding: 23px;
            box-shadow: 0 6px 20px #7d38500b;
            overflow-wrap: anywhere;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 24px #7d385018;
        }

        .card h3 {
            color: #a94367;
            font-size: 18px;
            line-height: 1.5;
            margin-bottom: 10px;
        }

        .card p {
            color: #6e6066;
            font-size: 14px;
            margin-bottom: 8px;
            overflow-wrap: anywhere;
        }

        .date {
            display: inline-block;
            background: #fff0f5;
            color: #a94367;
            padding: 5px 10px;
            border-radius: 7px;
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 12px;
        }

        /* FOTO GALERI */
        .photo {
            display: block;
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 14px;
            background: #f8e2eb;
        }

        /* DATA KOSONG */
        .empty {
            grid-column: 1 / -1;
            background: #fff;
            border: 1px solid #f2dce5;
            border-radius: 16px;
            padding: 30px 22px;
            text-align: center;
            color: #78666e;
            box-shadow: 0 6px 20px #7d38500b;
        }

        /* =========================
           TENTANG KAMI
        ========================= */
        .about {
            max-width: 850px;
            margin: auto;
            text-align: center;
        }

        .about p {
            margin-bottom: 14px;
            color: #66545c;
        }

        /* =========================
           CTA
        ========================= */
        .cta {
            max-width: 1050px;
            margin: auto;
            padding: 35px;
            text-align: center;
            border-radius: 18px;
            background: linear-gradient(135deg, #f6d2df, #fff0f5);
            border: 1px solid #f2dce5;
        }

        .cta h2 {
            color: #a94367;
            margin-bottom: 10px;
        }

        .cta p {
            color: #66545c;
        }

        /* =========================
           FOOTER
        ========================= */
        footer {
            background: #a94367;
            color: #fff;
            padding: 25px 7%;
            text-align: center;
            font-size: 13px;
        }

        /* =========================
           TABLET
        ========================= */
        @media (max-width: 800px) {
            .navbar {
                flex-direction: column;
                padding: 15px 5%;
            }

            .menu {
                justify-content: center;
                gap: 13px;
            }

            .cards {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }

            .hero {
                padding: 65px 6%;
            }

            .section {
                padding: 50px 5%;
            }
        }

        /* =========================
           HP
        ========================= */
        @media (max-width: 540px) {
            .brand {
                font-size: 19px;
            }

            .menu {
                gap: 12px;
            }

            .menu a {
                font-size: 13px;
            }

            .hero {
                padding: 45px 5%;
            }

            .hero h1 {
                font-size: 30px;
            }

            .section {
                padding: 42px 5%;
            }

            .section-heading h2 {
                font-size: 24px;
            }

            .cards {
                grid-template-columns: 1fr;
                gap: 18px;
            }

            .card {
                padding: 18px;
            }

            .photo {
                height: 220px;
            }

            .cta {
                padding: 25px 16px;
            }

            footer {
                padding: 22px 5%;
            }
        }
    </style>
</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar">
        <a class="brand" href="index.php">
            🌿 Karang Taruna
        </a>

        <div class="menu">
            <a href="index.php">Beranda</a>
            <a href="tentang.php">Profil</a>
            <a href="kegiatan/kegiatan.php">Kegiatan</a>
            <a href="galeri/galeri.php">Galeri</a>

            <?php if ($sudahLogin): ?>
                <a
                    class="menu-login"
                    href="<?= htmlspecialchars($linkDashboard, ENT_QUOTES, 'UTF-8'); ?>"
                >
                    Dashboard
                </a>
            <?php else: ?>
                <a class="menu-login" href="login.php">Login</a>
            <?php endif; ?>
        </div>
    </nav>

    <!-- HERO -->
    <header class="hero">
        <div class="hero-inner">
            <span class="label">Karang Taruna Desa</span>

            <h1>
                Bersama Pemuda,<br>
                Bangun Lingkungan Lebih Baik
            </h1>

            <p>
                Selamat datang di website Karang Taruna Lintang Sakti.
                Temukan informasi kegiatan, dokumentasi, dan berbagai
                aktivitas kepemudaan dalam satu tempat.
            </p>

            <a class="button button-primary" href="kegiatan/kegiatan.php">
                Lihat Kegiatan
            </a>

            <a class="button button-secondary" href="tentang.php">
                Tentang Kami
            </a>
        </div>
    </header>

    <!-- SELAMAT DATANG -->
    <section class="section">
        <div class="section-heading">
            <h2>Selamat Datang</h2>
            <p>
                Wadah bagi generasi muda untuk berorganisasi,
                bergotong royong, dan berkontribusi bagi masyarakat.
            </p>
        </div>

        <div class="about">
            <p>
                Karang Taruna Lintang Sakti mendorong pemuda agar aktif,
                kreatif, bertanggung jawab, dan peduli terhadap lingkungan.
            </p>

            <p>
                Website ini memudahkan pengunjung memperoleh informasi,
                sedangkan admin dapat mengelola data organisasi melalui
                dashboard sesuai hak aksesnya.
            </p>
        </div>
    </section>

    <!-- KEGIATAN TERBARU -->
    <section class="section section-soft">
        <div class="section-heading">
            <h2>Kegiatan Terbaru</h2>
            <p>Informasi kegiatan yang tercatat dalam sistem.</p>
        </div>

        <div class="cards">
            <?php if ($queryKegiatan && mysqli_num_rows($queryKegiatan) > 0): ?>

                <?php while ($kegiatan = mysqli_fetch_assoc($queryKegiatan)): ?>
                    <article class="card">

                        <span class="date">
                            <?php
                            if (!empty($kegiatan['tanggal'])) {
                                echo htmlspecialchars(
                                    date(
                                        'd-m-Y',
                                        strtotime($kegiatan['tanggal'])
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                            } else {
                                echo 'Tanggal belum ditentukan';
                            }
                            ?>
                        </span>

                        <h3>
                            <?= htmlspecialchars(
                                $kegiatan['nama_kegiatan'] ?? 'Kegiatan',
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>
                        </h3>

                        <p>
                            <strong>Lokasi:</strong>
                            <?= htmlspecialchars(
                                $kegiatan['lokasi'] ?? 'Belum ditentukan',
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>
                        </p>

                        <p>
                            <?php
                            $deskripsi = $kegiatan['deskripsi']
                                ?? 'Belum ada deskripsi.';

                            if (function_exists('mb_strimwidth')) {
                                $deskripsi = mb_strimwidth(
                                    $deskripsi,
                                    0,
                                    150,
                                    '...'
                                );
                            } elseif (strlen($deskripsi) > 150) {
                                $deskripsi = substr($deskripsi, 0, 147) . '...';
                            }

                            echo htmlspecialchars(
                                $deskripsi,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>
                        </p>

                    </article>
                <?php endwhile; ?>

            <?php else: ?>

                <div class="empty">
                    Belum ada data kegiatan. Informasi kegiatan akan tampil
                    setelah admin menambahkan data.
                </div>

            <?php endif; ?>
        </div>

        <div style="text-align:center; margin-top:28px;">
            <a class="button button-primary" href="kegiatan/kegiatan.php">
                Lihat Semua Kegiatan
            </a>
        </div>
    </section>

    <!-- DOKUMENTASI GALERI -->
    <section class="section">
        <div class="section-heading">
            <h2>Dokumentasi Kegiatan</h2>
            <p>Foto kegiatan yang dikelola melalui menu galeri.</p>
        </div>

        <div class="cards">
            <?php if ($queryGaleri && mysqli_num_rows($queryGaleri) > 0): ?>

                <?php while ($foto = mysqli_fetch_assoc($queryGaleri)): ?>
                    <article class="card">

                        <?php
                        $namaFoto = basename($foto['foto'] ?? '');
                        $lokasiFile = __DIR__ . '/uploads/' . $namaFoto;
                        $urlFoto = 'uploads/' . rawurlencode($namaFoto);
                        ?>

                        <?php if ($namaFoto !== '' && is_file($lokasiFile)): ?>
                            <img
                                class="photo"
                                src="<?= htmlspecialchars($urlFoto, ENT_QUOTES, 'UTF-8'); ?>"
                                alt="<?= htmlspecialchars(
                                    $foto['judul'] ?? 'Foto kegiatan',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                loading="lazy"
                            >
                        <?php else: ?>
                            <div class="empty">
                                Foto belum tersedia.
                            </div>
                        <?php endif; ?>

                        <h3>
                            <?= htmlspecialchars(
                                $foto['judul'] ?? 'Dokumentasi',
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>
                        </h3>

                        <p>
                            <?= nl2br(htmlspecialchars(
                                $foto['keterangan'] ?? '',
                                ENT_QUOTES,
                                'UTF-8'
                            )); ?>
                        </p>

                    </article>
                <?php endwhile; ?>

            <?php else: ?>

                <div class="empty">
                    Belum ada foto galeri yang ditampilkan.
                </div>

            <?php endif; ?>
        </div>

        <div style="text-align:center; margin-top:28px;">
            <a class="button button-secondary" href="galeri/galeri.php">
                Buka Galeri
            </a>
        </div>
    </section>

    <!-- AJAKAN -->
    <section class="section section-soft">
        <div class="cta">
            <h2>Ingin Melihat Informasi Organisasi?</h2>

            <p>
                Jelajahi kegiatan dan dokumentasi Karang Taruna Lintang Sakti.
                Pengelolaan data dilakukan melalui akun admin.
            </p>

            <?php if ($sudahLogin): ?>
                <a
                    class="button button-primary"
                    href="<?= htmlspecialchars($linkDashboard, ENT_QUOTES, 'UTF-8'); ?>"
                >
                    Buka Dashboard
                </a>
            <?php else: ?>
                <a class="button button-primary" href="login.php">
                    Login ke Sistem
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- FOOTER -->
    <footer>
        &copy; <?= date('Y'); ?> Karang Taruna Lintang Sakti.
        Bersama membangun pemuda yang aktif dan peduli.
    </footer>

</body>
</html>
