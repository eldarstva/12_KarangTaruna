<?php
include __DIR__ . '/../koneksi.php';

/* =====================================================
   FUNGSI MENGHITUNG JUMLAH DATA
   ===================================================== */

function hitungData($koneksi, $tabel)
{
    $tabelDiizinkan = ['anggota', 'kegiatan', 'galeri'];

    if (!in_array($tabel, $tabelDiizinkan)) {
        return 0;
    }

    $query = mysqli_query(
        $koneksi,
        "SELECT COUNT(*) AS total FROM $tabel"
    );

    if ($query) {
        $data = mysqli_fetch_assoc($query);
        return $data['total'];
    }

    return 0;
}


/* =====================================================
   JUMLAH DATA
   ===================================================== */

$totalAnggota  = hitungData($koneksi, 'anggota');
$totalKegiatan = hitungData($koneksi, 'kegiatan');
$totalGaleri   = hitungData($koneksi, 'galeri');

/* Statistik kegiatan per bulan untuk grafik dashboard */
$grafikKegiatan = array_fill(1, 12, 0);
$qGrafik = mysqli_query($koneksi, "SELECT MONTH(tanggal) AS bulan, COUNT(*) AS total FROM kegiatan WHERE YEAR(tanggal) = YEAR(CURDATE()) GROUP BY MONTH(tanggal)");
if ($qGrafik) {
    while ($rowGrafik = mysqli_fetch_assoc($qGrafik)) {
        $grafikKegiatan[(int)$rowGrafik['bulan']] = (int)$rowGrafik['total'];
    }
}
$namaBulan = [1=>'Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
$maxGrafik = max(1, max($grafikKegiatan));


/* =====================================================
   KEGIATAN MENDATANG
   ===================================================== */

$queryMendatang = mysqli_query(
    $koneksi,
    "SELECT *
     FROM kegiatan
     WHERE tanggal >= CURDATE()
     ORDER BY tanggal ASC
     LIMIT 5"
);


/* =====================================================
   JUMLAH KEGIATAN MENDATANG
   ===================================================== */

$queryJumlahMendatang = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total
     FROM kegiatan
     WHERE tanggal >= CURDATE()"
);

$totalMendatang = 0;

if ($queryJumlahMendatang) {

    $dataMendatang = mysqli_fetch_assoc(
        $queryJumlahMendatang
    );

    $totalMendatang = $dataMendatang['total'];
}


/* =====================================================
   KEGIATAN TERBARU
   ===================================================== */

$queryTerbaru = mysqli_query(
    $koneksi,
    "SELECT *
     FROM kegiatan
     ORDER BY tanggal DESC
     LIMIT 5"
);

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Dashboard Admin - Karang Taruna
    </title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        body {

            font-family:
                Arial,
                Helvetica,
                sans-serif;

            background: #fff7fa;

            color: #4d4146;

        }


        /* =====================================================
           LAYOUT
           ===================================================== */

        .layout {

            display: flex;

            min-height: 100vh;

        }


        /* =====================================================
           SIDEBAR
           ===================================================== */

        .sidebar {

            width: 250px;

            background: white;

            position: fixed;

            left: 0;

            top: 0;

            bottom: 0;

            padding: 25px 15px 20px;

            overflow-y: auto;

            overflow-x: hidden;

            box-shadow:
                3px 0 15px
                rgba(0,0,0,0.06);

            z-index: 1000;

        }


        .logo {

            display: flex;

            align-items: center;

            gap: 10px;

            padding: 5px 10px 25px;

            border-bottom:
                1px solid #f4e3e9;

        }


        .logo-icon {

            width: 45px;

            height: 45px;

            border-radius: 13px;

            background:
                linear-gradient(
                    135deg,
                    #f4bfd0,
                    #d987a5
                );

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 23px;

        }


        .logo-text h2 {

            color: #bd708a;

            font-size: 17px;

        }


        .logo-text p {

            color: #999;

            font-size: 11px;

            margin-top: 4px;

        }


        .menu-title {

            font-size: 10px;

            color: #b6a2ab;

            font-weight: bold;

            margin:

                25px 10px 10px;

            letter-spacing: 1px;

        }


        .menu {

            list-style: none;

        }


        .menu li {

            margin-bottom: 5px;

        }


        .menu a {

            display: flex;

            align-items: center;

            gap: 13px;

            text-decoration: none;

            color: #76656d;

            padding: 12px;

            border-radius: 10px;

            font-size: 14px;

            transition: 0.2s;

        }


        .menu a:hover {

            background: #fce9f0;

            color: #bd6488;

        }


        .menu a.active {

            background: #fce9f0;

            color: #bd6488;

            font-weight: bold;

        }


        .icon {

            width: 23px;

            text-align: center;

            font-size: 17px;

        }


        .logout {

            position: static;

            margin: 12px 0 0;

            padding: 0;

        }


        .logout a {

            display: block;

            padding: 12px;

            text-decoration: none;

            color: #d05f78;

            font-weight: bold;

            border-radius: 10px;

        }


        .logout a:hover {

            background: #fff0f4;

        }


        /* =====================================================
           MAIN
           ===================================================== */

        .main {

            width: calc(100% - 250px);

            margin-left: 250px;

        }


        /* =====================================================
           TOPBAR
           ===================================================== */

        .topbar {

            height: 75px;

            background: white;

            display: flex;

            align-items: center;

            justify-content:
                space-between;

            padding: 0 35px;

            box-shadow:
                0 2px 10px
                rgba(0,0,0,0.04);

        }


        .topbar h2 {

            font-size: 20px;

            color: #5b4850;

        }


        .topbar p {

            color: #a18d96;

            font-size: 12px;

            margin-top: 4px;

        }


        .admin {

            display: flex;

            align-items: center;

            gap: 10px;

        }


        .avatar {

            width: 40px;

            height: 40px;

            border-radius: 50%;

            background: #fce5ee;

            display: flex;

            align-items: center;

            justify-content: center;

            color: #bd6488;

            font-size: 19px;

        }


        .admin-text strong {

            display: block;

            font-size: 13px;

        }


        .admin-text span {

            color: #a18d96;

            font-size: 11px;

        }


        /* =====================================================
           CONTENT
           ===================================================== */

        .content {

            padding: 30px;

        }


        /* =====================================================
           WELCOME
           ===================================================== */

        .welcome {

            background:
                linear-gradient(
                    120deg,
                    #e99ab3,
                    #ca7b99
                );

            color: white;

            padding: 30px;

            border-radius: 17px;

            display: flex;

            align-items: center;

            justify-content:
                space-between;

            box-shadow:
                0 8px 20px
                rgba(205,124,154,0.18);

        }


        .welcome h1 {

            font-size: 26px;

            margin-bottom: 10px;

        }


        .welcome p {

            font-size: 14px;

            line-height: 1.7;

            max-width: 650px;

        }


        .welcome-icon {

            font-size: 65px;

        }


        /* =====================================================
           SECTION TITLE
           ===================================================== */

        .section-title {

            margin:

                30px 0 18px;

        }


        .section-title h2 {

            color: #624d57;

            font-size: 19px;

        }


        .section-title p {

            color: #a18d96;

            font-size: 12px;

            margin-top: 5px;

        }


        /* =====================================================
           STATISTIK
           ===================================================== */

        .stats {

            display: grid;

            grid-template-columns:
                repeat(4, 1fr);

            gap: 18px;

        }


        .stat-card {

            background: white;

            padding: 20px;

            border-radius: 14px;

            border:
                1px solid #f7e8ed;

            box-shadow:
                0 4px 15px
                rgba(0,0,0,0.05);

            transition: 0.2s;

        }


        .stat-card:hover {

            transform:
                translateY(-4px);

        }


        .stat-top {

            display: flex;

            justify-content:
                space-between;

            align-items: center;

            margin-bottom: 15px;

        }


        .stat-icon {

            width: 43px;

            height: 43px;

            border-radius: 12px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 20px;

        }


        .pink {

            background: #fce5ee;

        }


        .purple {

            background: #eee8ff;

        }


        .orange {

            background: #fff0dd;

        }


        .green {

            background: #e5f6ec;

        }


        .stat-label {

            font-size: 12px;

            color: #9b8790;

        }


        .stat-number {

            font-size: 30px;

            font-weight: bold;

            color: #5d4751;

        }


        .stat-note {

            color: #a18d96;

            font-size: 11px;

            margin-top: 7px;

        }


        /* =====================================================
           KEGIATAN MENDATANG
           ===================================================== */

        .mendatang-box {

            background: white;

            padding: 22px;

            border-radius: 14px;

            box-shadow:
                0 4px 15px
                rgba(0,0,0,0.05);

        }


        .mendatang-list {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 15px;

        }


        .mendatang-item {

            background: #fff8fb;

            border-left:
                4px solid #e99ab3;

            padding: 17px;

            border-radius: 10px;

            transition: 0.2s;

        }


        .mendatang-item:hover {

            transform:
                translateY(-3px);

            box-shadow:
                0 5px 15px
                rgba(0,0,0,0.06);

        }


        .mendatang-item h3 {

            color: #bd708a;

            font-size: 16px;

            margin-bottom: 10px;

        }


        .mendatang-item p {

            color: #71626a;

            font-size: 12px;

            margin-top: 7px;

        }


        .tanggal {

            display: inline-block;

            background: #fce5ee;

            color: #bd6488;

            padding: 5px 9px;

            border-radius: 20px;

            font-size: 10px;

            font-weight: bold;

            margin-bottom: 8px;

        }


        .tidak-ada {

            text-align: center;

            padding: 30px;

            color: #999;

            font-size: 13px;

        }


        /* =====================================================
           AKSES CEPAT
           ===================================================== */

        .quick {

            display: grid;

            grid-template-columns:
                repeat(3, 1fr);

            gap: 15px;

        }


        .quick a {

            background: white;

            border:
                1px solid #f4e3e9;

            padding: 18px;

            border-radius: 12px;

            text-decoration: none;

            display: flex;

            align-items: center;

            gap: 13px;

            color: #5e4a54;

            transition: 0.2s;

        }


        .quick a:hover {

            border-color: #e99ab3;

            transform:
                translateY(-3px);

        }


        .quick-icon {

            width: 42px;

            height: 42px;

            background: #fce9f0;

            border-radius: 10px;

            display: flex;

            align-items: center;

            justify-content: center;

            font-size: 20px;

        }


        .quick strong {

            display: block;

            font-size: 13px;

            margin-bottom: 4px;

        }


        .quick span {

            font-size: 11px;

            color: #a18d96;

        }


        .chart-panel { background:#fff; padding:22px; border-radius:16px; box-shadow:0 4px 15px rgba(0,0,0,.05); margin:24px 0; }
        .chart-panel h2 { color:#bd708a; margin-bottom:6px; font-size:20px; }
        .chart-bars { display:grid; grid-template-columns:repeat(12,minmax(18px,1fr)); gap:10px; align-items:end; height:190px; margin-top:22px; }
        .chart-col { height:100%; display:flex; flex-direction:column; justify-content:flex-end; align-items:center; gap:7px; min-width:0; }
        .chart-bar { width: min(100%,30px); min-height:4px; background:linear-gradient(180deg,#efb5c9,#d987a5); border-radius:7px 7px 2px 2px; }
        .chart-col small { color:#9a7f8a; font-size:11px; }
        .chart-col b { color:#bd708a; font-size:11px; }
        @media(max-width:650px){.chart-panel{padding:14px}.chart-bars{gap:4px}.chart-col small{font-size:9px}}

        /* =====================================================
           TABEL KEGIATAN
           ===================================================== */

        .table-box {

            background: white;

            padding: 20px;

            border-radius: 14px;

            box-shadow:
                0 4px 15px
                rgba(0,0,0,0.05);

            overflow-x: auto;

        }


        table {

            width: 100%;

            border-collapse:
                collapse;

            min-width: 600px;

        }


        th {

            background: #fff4f8;

            color: #a17083;

            padding: 13px;

            text-align: left;

            font-size: 12px;

        }


        td {

            padding: 14px 13px;

            border-bottom:
                1px solid #f5e9ed;

            font-size: 12px;

            color: #66545d;

        }


        .status {

            display: inline-block;

            background: #fce9f0;

            color: #bd6488;

            padding: 5px 9px;

            border-radius: 20px;

            font-size: 10px;

            font-weight: bold;

        }


        /* =====================================================
           FOOTER
           ===================================================== */

        footer {

            text-align: center;

            color: #aa939d;

            font-size: 11px;

            padding: 25px;

        }


        /* =====================================================
           MOBILE
           ===================================================== */

        @media (max-width: 1000px) {

            .stats {

                grid-template-columns:
                    repeat(2, 1fr);

            }


            .mendatang-list {

                grid-template-columns:
                    repeat(2, 1fr);

            }

        }


        @media (max-width: 700px) {

            .sidebar {

                transform:
                    translateX(-100%);

            }


            .sidebar.show {

                transform:
                    translateX(0);

            }


            .main {

                width: 100%;

                margin-left: 0;

            }


            .topbar {

                padding: 0 18px;

            }


            .content {

                padding: 18px;

            }


            .welcome {

                padding: 22px;

            }


            .welcome-icon {

                display: none;

            }


            .mendatang-list {

                grid-template-columns: 1fr;

            }


            .quick {

                grid-template-columns: 1fr;

            }

        }


        @media (max-width: 500px) {

            .stats {

                grid-template-columns:
                    repeat(2, 1fr);

                gap: 10px;

            }


            .stat-card {

                padding: 14px;

            }


            .stat-number {

                font-size: 24px;

            }


            .stat-label {

                font-size: 10px;

            }


            .admin-text {

                display: none;

            }

        }

    </style>

</head>


<body>


<div class="layout">


    <!-- =================================================
         SIDEBAR
         ================================================= -->

    <aside class="sidebar" id="sidebar">


        <div class="logo">

            <div class="logo-icon">
                🌿
            </div>

            <div class="logo-text">

                <h2>
                    Lintang Sakti
                </h2>

                <p>
                    Karang Taruna
                </p>

            </div>

        </div>


        <p class="menu-title">
            MENU UTAMA
        </p>


        <ul class="menu">

            <li>

                <a
                    href="admin.php"
                    class="active"
                >

                    <span class="icon">
                        ▦
                    </span>

                    Dashboard

                </a>

            </li>


            <li>

                <a href="../absensi.php">

                    <span class="icon">
                        ✓
                    </span>

                    Absensi Kegiatan

                </a>

            </li>

            <li>
                <a href="../rekap_absensi.php">
                    <span class="icon">📊</span>
                    Rekap Absensi
                </a>
            </li>


            <li>

                <a href="../index.php">

                    <span class="icon">
                        ⌂
                    </span>

                    Beranda Website

                </a>

            </li>


            <li>

                <a href="../tentang.php">

                    <span class="icon">
                        ♡
                    </span>

                    Profil

                </a>

            </li>

        </ul>


        <p class="menu-title">
            KELOLA DATA
        </p>


        <ul class="menu">

            <li>

                <a href="../anggota/anggota.php">

                    <span class="icon">
                        👥
                    </span>

                    Anggota

                </a>

            </li>


            <li>

                <a href="../kegiatan/kegiatan.php">

                    <span class="icon">
                        📅
                    </span>

                    Kegiatan

                </a>

            </li>


            <li>

                <a href="../galeri/galeri.php">

                    <span class="icon">
                        🖼️
                    </span>

                    Galeri

                </a>

            </li>

        </ul>


        <p class="menu-title">
            AKUN
        </p>


        <ul class="menu">

            <li>

                <a
                    href="../logout.php"
                    onclick="
                    return confirm(
                        'Yakin ingin logout?'
                    )
                    "
                >

                    <span class="icon">
                        🚪
                    </span>

                    Logout

                </a>

            </li>

        </ul>


        <div class="logout">

            <a href="../index.php">

                🌸 Lihat Website

            </a>

        </div>


    </aside>


    <!-- =================================================
         MAIN
         ================================================= -->

    <main class="main">


        <!-- TOPBAR -->

        <header class="topbar">


            <div>

                <h2>
                    Dashboard
                </h2>

                <p>
                    Panel Admin Karang Taruna
                </p>

            </div>


            <div class="admin">

                <div class="avatar">
                    ♙
                </div>

                <div class="admin-text">

                    <strong>
                        Administrator
                    </strong>

                    <span>
                        Pengelola Website
                    </span>

                </div>

            </div>


        </header>


        <!-- CONTENT -->

        <div class="content">


            <!-- =================================================
                 WELCOME
                 ================================================= -->

            <section class="welcome">


                <div>

                    <h1>
                        Selamat Datang, Admin! 🌷
                    </h1>

                    <p>

                        Kelola data Karang Taruna
                        Lintang Sakti dengan mudah.
                        Tambahkan kegiatan, anggota,
                        dan dokumentasi organisasi
                        melalui dashboard ini.

                    </p>

                </div>


                <div class="welcome-icon">

                    🌸

                </div>


            </section>



            <!-- =================================================
                 STATISTIK
                 ================================================= -->

            <div class="section-title">

                <h2>
                    Ringkasan Data
                </h2>

                <p>
                    Informasi data Karang Taruna
                </p>

            </div>


            <section class="stats">


                <!-- ANGGOTA -->

                <div class="stat-card" role="link" tabindex="0" onclick="location.href='../anggota/anggota.php'" onkeydown="if(event.key==='Enter')location.href='../anggota/anggota.php'" style="cursor:pointer">

                    <div class="stat-top">

                        <span class="stat-label">
                            Total Anggota
                        </span>

                        <div class="stat-icon pink">
                            👥
                        </div>

                    </div>

                    <div class="stat-number">
                        <?= $totalAnggota ?>
                    </div>

                    <p class="stat-note">
                        Anggota terdaftar
                    </p>

                </div>


                <!-- KEGIATAN -->

                <div class="stat-card" role="link" tabindex="0" onclick="location.href='../kegiatan/kegiatan.php'" onkeydown="if(event.key==='Enter')location.href='../kegiatan/kegiatan.php'" style="cursor:pointer">

                    <div class="stat-top">

                        <span class="stat-label">
                            Total Kegiatan
                        </span>

                        <div class="stat-icon purple">
                            📅
                        </div>

                    </div>

                    <div class="stat-number">
                        <?= $totalKegiatan ?>
                    </div>

                    <p class="stat-note">
                        Data kegiatan
                    </p>

                </div>


                <!-- GALERI -->

                <div class="stat-card" role="link" tabindex="0" onclick="location.href='../galeri/galeri.php'" onkeydown="if(event.key==='Enter')location.href='../galeri/galeri.php'" style="cursor:pointer">

                    <div class="stat-top">

                        <span class="stat-label">
                            Total Galeri
                        </span>

                        <div class="stat-icon orange">
                            🖼️
                        </div>

                    </div>

                    <div class="stat-number">
                        <?= $totalGaleri ?>
                    </div>

                    <p class="stat-note">
                        Foto dokumentasi
                    </p>

                </div>


                <!-- MENDATANG -->

                <div class="stat-card">

                    <div class="stat-top">

                        <span class="stat-label">
                            Kegiatan Mendatang
                        </span>

                        <div class="stat-icon green">
                            🗓️
                        </div>

                    </div>

                    <div class="stat-number">
                        <?= $totalMendatang ?>
                    </div>

                    <p class="stat-note">
                        Belum terlaksana
                    </p>

                </div>


            </section>

            <section class="chart-panel">
                <h2>📊 Statistik Kegiatan Tahun Ini</h2>
                <p style="color:#9a7f8a;font-size:13px">Jumlah kegiatan yang tercatat setiap bulan.</p>
                <div class="chart-bars">
                    <?php foreach ($grafikKegiatan as $nomorBulan => $jumlah): ?>
                        <div class="chart-col" title="<?= htmlspecialchars($namaBulan[$nomorBulan]) ?>: <?= $jumlah ?> kegiatan">
                            <b><?= $jumlah ?></b>
                            <div class="chart-bar" style="height:<?= max(4, (int)(($jumlah / $maxGrafik) * 145)) ?>px"></div>
                            <small><?= $namaBulan[$nomorBulan] ?></small>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <!-- =================================================
                 KEGIATAN MENDATANG
                 ================================================= -->

            <div class="section-title">

                <h2>
                    Kegiatan Mendatang
                </h2>

                <p>
                    Jadwal kegiatan yang akan dilaksanakan
                </p>

            </div>


            <section class="mendatang-box">


                <div class="mendatang-list">


                    <?php

                    if (
                        $queryMendatang &&
                        mysqli_num_rows(
                            $queryMendatang
                        ) > 0
                    ):

                    ?>


                        <?php

                        while (
                            $data =
                            mysqli_fetch_assoc(
                                $queryMendatang
                            )
                        ):

                        ?>


                            <div class="mendatang-item">


                                <span class="tanggal">

                                    📅

                                    <?= date(
                                        'd-m-Y',
                                        strtotime(
                                            $data['tanggal']
                                        )
                                    ); ?>

                                </span>


                                <h3>

                                    <?= htmlspecialchars(
                                        $data[
                                            'nama_kegiatan'
                                        ]
                                    ); ?>

                                </h3>


                                <p>

                                    📍

                                    <?= htmlspecialchars(
                                        $data['lokasi']
                                    ); ?>

                                </p>


                            </div>


                        <?php

                        endwhile;

                        ?>


                    <?php

                    else:

                    ?>


                        <div
                            class="tidak-ada"
                            style="
                                grid-column:
                                1 / -1;
                            "
                        >

                            📅

                            <br><br>

                            Belum ada kegiatan
                            mendatang.

                            <br>

                            Silakan tambahkan
                            kegiatan baru.

                        </div>


                    <?php

                    endif;

                    ?>


                </div>


            </section>



            <!-- =================================================
                 AKSES CEPAT
                 ================================================= -->

            <div class="section-title">

                <h2>
                    Akses Cepat
                </h2>

                <p>
                    Kelola data dengan cepat
                </p>

            </div>


            <section class="quick">


                <a href="../kegiatan/kegiatan_tambah.php">

                    <div class="quick-icon">
                        📅
                    </div>

                    <div>

                        <strong>
                            Tambah Kegiatan
                        </strong>

                        <span>
                            Buat kegiatan baru
                        </span>

                    </div>

                </a>


                <a href="../anggota/anggota_tambah.php">

                    <div class="quick-icon">
                        👤
                    </div>

                    <div>

                        <strong>
                            Tambah Anggota
                        </strong>

                        <span>
                            Tambahkan anggota
                        </span>

                    </div>

                </a>


                <a href="../galeri/galeri_tambah.php">

                    <div class="quick-icon">
                        📷
                    </div>

                    <div>

                        <strong>
                            Tambah Galeri
                        </strong>

                        <span>
                            Tambahkan dokumentasi
                        </span>

                    </div>

                </a>


            </section>



            <!-- =================================================
                 KEGIATAN TERBARU
                 ================================================= -->

            <div class="section-title">

                <h2>
                    Kegiatan Terbaru
                </h2>

                <p>
                    Data kegiatan yang terakhir ditambahkan
                </p>

            </div>


            <section class="table-box">


                <table>


                    <thead>

                        <tr>

                            <th>
                                No
                            </th>

                            <th>
                                Nama Kegiatan
                            </th>

                            <th>
                                Tanggal
                            </th>

                            <th>
                                Lokasi
                            </th>

                            <th>
                                Status
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                    <?php

                    if (
                        $queryTerbaru &&
                        mysqli_num_rows(
                            $queryTerbaru
                        ) > 0
                    ):

                    ?>


                        <?php

                        $no = 1;

                        while (
                            $data =
                            mysqli_fetch_assoc(
                                $queryTerbaru
                            )
                        ):

                        ?>


                            <tr>


                                <td>
                                    <?= $no++ ?>
                                </td>


                                <td>

                                    <strong>

                                        <?= htmlspecialchars(
                                            $data[
                                                'nama_kegiatan'
                                            ]
                                        ); ?>

                                    </strong>

                                </td>


                                <td>

                                    <?= date(
                                        'd-m-Y',
                                        strtotime(
                                            $data['tanggal']
                                        )
                                    ); ?>

                                </td>


                                <td>

                                    <?= htmlspecialchars(
                                        $data['lokasi']
                                    ); ?>

                                </td>


                                <td>


                                    <?php

                                    if (
                                        strtotime(
                                            $data['tanggal']
                                        ) >=
                                        strtotime(
                                            date('Y-m-d')
                                        )
                                    ) {

                                        $status =
                                            'Akan Datang';

                                    } else {

                                        $status =
                                            'Terlaksana';

                                    }

                                    ?>


                                    <span class="status">

                                        <?= $status ?>

                                    </span>


                                </td>


                            </tr>


                        <?php

                        endwhile;

                        ?>


                    <?php

                    else:

                    ?>


                        <tr>

                            <td
                                colspan="5"
                                style="
                                    text-align:center;
                                    padding:30px;
                                    color:#999;
                                "
                            >

                                Belum ada data kegiatan.

                            </td>

                        </tr>


                    <?php

                    endif;

                    ?>


                    </tbody>


                </table>


            </section>



            <!-- FOOTER -->

            <footer>

                &copy;
                <?= date('Y') ?>

                Karang Taruna
                Lintang Sakti

                <br>

                Sistem Informasi
                Karang Taruna

            </footer>


        </div>


    </main>


</div>


</body>

</html>