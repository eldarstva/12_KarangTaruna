<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - Karang Taruna Lintang Sakti</title>

    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #fff7fa;
            color: #444;
        }
        nav {
            background: #e89ab2;
            padding: 18px 4%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }
        .logo {
            color: white;
            font-size: 22px;
            font-weight: bold;
            text-decoration: none;
        }
        .menu { display: flex; gap: 24px; flex-wrap: wrap; }
        .menu a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }
        .menu a:hover { color: #fff0f4; }
        .judul {
            text-align: center;
            padding: 50px 20px;
            background: linear-gradient(135deg, #fff0f5, #f8d5e1);
        }
        .judul h1 { color: #c96889; margin-bottom: 10px; }
        main {
            max-width: 1000px;
            margin: auto;
            padding: 35px 20px 50px;
        }
        .kartu {
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 22px;
            box-shadow: 0 3px 12px #00000010;
            line-height: 1.8;
        }
        h2 { color: #c96889; margin-top: 0; }
        li { margin-bottom: 10px; }
        footer {
            background: #d77f9d;
            color: white;
            text-align: center;
            padding: 18px;
        }
        @media (max-width: 600px) {
            nav { justify-content: center; }
            .menu { justify-content: center; gap: 14px; }
        }
    </style>
</head>

<body>
<nav>
    <a class="logo" href="index.php">🌿 Karang Taruna</a>
    <div class="menu">
        <a href="index.php">Beranda</a>
        <a href="tentang.php">Profil</a>
        <a href="kegiatan/kegiatan.php">Kegiatan</a>
        <a href="login.php">Login</a>
    </div>
</nav>

<header class="judul">
    <h1>Profil Karang Taruna</h1>
    <p>Mengenal Karang Taruna Lintang Sakti lebih dekat</p>
</header>

<main>
    <div class="kartu">
        <h2>Tentang Kami</h2>
        <p>
            Karang Taruna Lintang Sakti adalah organisasi kepemudaan
            yang menjadi wadah bagi para pemuda untuk mengembangkan
            potensi diri, meningkatkan kepedulian sosial, dan berperan
            aktif dalam pembangunan lingkungan masyarakat.
        </p>
        <p>
            Kami mengutamakan kerja sama, tanggung jawab, kreativitas,
            dan semangat gotong royong dalam menjalankan kegiatan.
        </p>
    </div>

    <div class="kartu">
        <h2>Visi</h2>
        <p>
            Mewujudkan generasi muda yang aktif, kreatif, mandiri,
            peduli terhadap masyarakat, serta memiliki semangat
            persatuan dan gotong royong.
        </p>
    </div>

    <div class="kartu">
        <h2>Misi</h2>
        <ol>
            <li>Meningkatkan persatuan dan kebersamaan pemuda.</li>
            <li>Mengembangkan kreativitas dan kemampuan generasi muda.</li>
            <li>Mendorong kegiatan sosial yang bermanfaat bagi masyarakat.</li>
            <li>Menumbuhkan kepedulian terhadap kebersihan lingkungan.</li>
            <li>Meningkatkan kerja sama dengan masyarakat setempat.</li>
        </ol>
    </div>

    <div class="kartu">
        <h2>Tujuan Organisasi</h2>
        <ul>
            <li>Menjadi tempat belajar berorganisasi bagi pemuda.</li>
            <li>Mengembangkan bakat, minat, dan keterampilan.</li>
            <li>Membangun lingkungan yang aman, bersih, dan harmonis.</li>
            <li>Mendorong pemuda agar berkontribusi positif bagi desa.</li>
        </ul>
    </div>
</main>

<footer>
    &copy; <?= date('Y') ?> Karang Taruna Lintang Sakti
</footer>
</body>
</html>

