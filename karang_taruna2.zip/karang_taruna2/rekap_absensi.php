<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/koneksi.php';

mysqli_report(MYSQLI_REPORT_OFF);

if (empty($_SESSION['login'])) {
    header('Location: login.php');
    exit;
}

$role = strtolower(
    $_SESSION['role']
    ?? $_SESSION['level']
    ?? $_SESSION['akses']
    ?? ''
);

if (!in_array($role, ['admin', 'administrator', 'anggota'], true)) {
    header('Location: login.php');
    exit;
}

function h($value) {
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function tanggalIndo($tanggal) {
    if (empty($tanggal)) {
        return '-';
    }

    $waktu = strtotime($tanggal);

    if ($waktu === false) {
        return '-';
    }

    return date('d-m-Y', $waktu);
}

function tanggalWaktuIndo($tanggal) {
    if (empty($tanggal)) {
        return '-';
    }

    $waktu = strtotime($tanggal);

    if ($waktu === false) {
        return '-';
    }

    return date('d-m-Y H:i', $waktu);
}

$dashboard = $role === 'anggota'
    ? 'anggota/anggota_dashboard.php'
    : 'admin/admin.php';

$error = '';
$rows = [];
$daftarKegiatan = [];

$totalHadir = 0;
$totalIzin = 0;
$totalSakit = 0;
$totalTidakHadir = 0;
$totalCatatan = 0;

$filterKegiatan = (int)($_GET['kegiatan_id'] ?? 0);
$filterTanggal = trim($_GET['tanggal'] ?? '');
$filterStatus = trim($_GET['status'] ?? '');

$statusValid = [
    'Hadir',
    'Izin',
    'Sakit',
    'Tidak Hadir'
];

if (!in_array($filterStatus, $statusValid, true)) {
    $filterStatus = '';
}

/*
|--------------------------------------------------------------------------
| AMBIL DAFTAR KEGIATAN
|--------------------------------------------------------------------------
*/

$sqlKegiatan = "
    SELECT id, nama_kegiatan, tanggal
    FROM kegiatan
    ORDER BY tanggal DESC, id DESC
";

$queryKegiatan = mysqli_query($koneksi, $sqlKegiatan);

if ($queryKegiatan) {
    while ($kegiatan = mysqli_fetch_assoc($queryKegiatan)) {
        $daftarKegiatan[] = $kegiatan;
    }
} else {
    $error = 'Gagal mengambil daftar kegiatan: '
           . mysqli_error($koneksi);
}

/*
|--------------------------------------------------------------------------
| VALIDASI FILTER TANGGAL
|--------------------------------------------------------------------------
*/

if (
    $filterTanggal !== '' &&
    !preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterTanggal)
) {
    $filterTanggal = '';
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA REKAP ABSENSI
|--------------------------------------------------------------------------
| Tanggal kegiatan berasal dari tabel kegiatan.
| Tanggal input berasal dari tabel absensi.
|--------------------------------------------------------------------------
*/

if ($error === '') {
    $sql = "
        SELECT
            a.id AS anggota_id,
            a.nama,
            COALESCE(a.jabatan, 'Anggota') AS jabatan,
            k.id AS kegiatan_id,
            k.nama_kegiatan,
            k.tanggal AS tanggal_kegiatan,
            abs.id AS absensi_id,
            abs.status,
            abs.keterangan,
            abs.tanggal_input,
            abs.updated_at
        FROM absensi abs
        INNER JOIN anggota a
            ON a.id = abs.anggota_id
        INNER JOIN kegiatan k
            ON k.id = abs.kegiatan_id
        WHERE 1 = 1
    ";

    $types = '';
    $params = [];

    if ($filterKegiatan > 0) {
        $sql .= " AND k.id = ?";
        $types .= 'i';
        $params[] = $filterKegiatan;
    }

    if ($filterTanggal !== '') {
        $sql .= " AND DATE(k.tanggal) = ?";
        $types .= 's';
        $params[] = $filterTanggal;
    }

    if ($filterStatus !== '') {
        $sql .= " AND abs.status = ?";
        $types .= 's';
        $params[] = $filterStatus;
    }

    $sql .= "
        ORDER BY
            k.tanggal DESC,
            k.id DESC,
            a.nama ASC
    ";

    $stmt = mysqli_prepare($koneksi, $sql);

    if (!$stmt) {
        $error = 'Gagal menyiapkan rekap absensi: '
               . mysqli_error($koneksi);
    } else {
        if ($types !== '') {
            mysqli_stmt_bind_param(
                $stmt,
                $types,
                ...$params
            );
        }

        if (!mysqli_stmt_execute($stmt)) {
            $error = 'Gagal membaca rekap absensi: '
                   . mysqli_stmt_error($stmt);
        } else {
            $hasil = mysqli_stmt_get_result($stmt);

            if ($hasil) {
                while ($row = mysqli_fetch_assoc($hasil)) {
                    $rows[] = $row;

                    $totalCatatan++;

                    if ($row['status'] === 'Hadir') {
                        $totalHadir++;
                    } elseif ($row['status'] === 'Izin') {
                        $totalIzin++;
                    } elseif ($row['status'] === 'Sakit') {
                        $totalSakit++;
                    } elseif ($row['status'] === 'Tidak Hadir') {
                        $totalTidakHadir++;
                    }
                }
            }
        }

        mysqli_stmt_close($stmt);
    }
}

/*
|--------------------------------------------------------------------------
| WARNA STATUS
|--------------------------------------------------------------------------
*/

function kelasStatus($status) {
    switch ($status) {
        case 'Hadir':
            return 'hadir';

        case 'Izin':
            return 'izin';

        case 'Sakit':
            return 'sakit';

        case 'Tidak Hadir':
            return 'tidak-hadir';

        default:
            return 'belum';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Rekap Absensi - Karang Taruna Lintang Sakti</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #fff7fa;
            color: #594952;
        }

        header {
            background: linear-gradient(120deg, #e99ab3, #c65f83);
            color: #fff;
            padding: 25px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        header h1 {
            font-size: 25px;
            margin-bottom: 7px;
        }

        header p {
            font-size: 14px;
            opacity: .95;
        }

        header a,
        .btn {
            display: inline-block;
            text-decoration: none;
            background: #fff;
            color: #a94367;
            padding: 10px 14px;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            font-size: 13px;
            cursor: pointer;
        }

        .btn-primary {
            background: #d66f96;
            color: #fff;
        }

        .btn-reset {
            background: #f5e3ea;
            color: #84425e;
        }

        main {
            max-width: 1400px;
            margin: 28px auto;
            padding: 0 20px;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: 15px;
            margin-bottom: 22px;
        }

        .card,
        .table-box,
        .filter-box {
            background: #fff;
            border: 1px solid #f3dce4;
            border-radius: 13px;
            padding: 20px;
            box-shadow: 0 4px 15px #00000008;
        }

        .card span {
            color: #987987;
            font-size: 13px;
        }

        .card strong {
            display: block;
            color: #bd708a;
            font-size: 28px;
            margin-top: 8px;
        }

        .filter-box {
            margin-bottom: 22px;
        }

        .filter-box h2,
        .table-box h2 {
            color: #bd708a;
            font-size: 20px;
            margin-bottom: 16px;
        }

        .filter-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 15px;
        }

        .field label {
            display: block;
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 7px;
        }

        .field select,
        .field input {
            width: 100%;
            padding: 11px;
            border: 1px solid #edcbd7;
            border-radius: 8px;
            background: #fffafd;
            color: #594952;
            font-size: 14px;
        }

        .filter-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 9px;
            margin-top: 16px;
        }

        .filter-actions a {
            text-decoration: none;
        }

        .table-box h2 {
            margin-bottom: 6px;
        }

        .subtitle {
            color: #987987;
            font-size: 13px;
            margin-bottom: 18px;
            line-height: 1.5;
        }

        .table-wrap {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            min-width: 1250px;
            border-collapse: collapse;
        }

        th {
            background: #e99ab3;
            color: #fff;
            text-align: left;
            padding: 12px;
            font-size: 13px;
            white-space: nowrap;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #f3dce4;
            font-size: 13px;
            vertical-align: top;
        }

        tbody tr:hover td {
            background: #fff8fb;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            white-space: nowrap;
        }

        .hadir {
            background: #d9f5e4;
            color: #217446;
        }

        .izin {
            background: #fff0c9;
            color: #8c6500;
        }

        .sakit {
            background: #dcecff;
            color: #245a99;
        }

        .tidak-hadir {
            background: #ffe0e0;
            color: #a52e2e;
        }

        .belum {
            background: #eee;
            color: #666;
        }

        .notice {
            padding: 14px;
            background: #fff0f4;
            border-radius: 8px;
            margin-bottom: 18px;
            color: #a94367;
            overflow-wrap: anywhere;
            line-height: 1.6;
        }

        .empty {
            padding: 30px 15px;
            text-align: center;
            color: #987987;
        }

        .date-cell {
            white-space: nowrap;
        }

        footer {
            text-align: center;
            padding: 22px 12px;
            color: #987987;
            font-size: 12px;
        }

        @media (max-width: 1000px) {
            .stats {
                grid-template-columns: repeat(3, minmax(0, 1fr));
            }

            .filter-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 600px) {
            header {
                padding: 20px;
            }

            header h1 {
                font-size: 21px;
            }

            main {
                padding: 0 12px;
                margin: 16px auto;
            }

            .stats {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 10px;
            }

            .card,
            .table-box,
            .filter-box {
                padding: 14px;
            }

            .card strong {
                font-size: 24px;
            }

            .filter-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>

<header>
    <div>
        <h1>📊 Rekap Absensi Anggota</h1>
        <p>Karang Taruna Lintang Sakti</p>
    </div>

    <a href="<?= h($dashboard) ?>">
        &#8592; Kembali ke Dashboard
    </a>
</header>

<main>

    <?php if ($error !== ''): ?>
        <div class="notice">
            <?= h($error) ?>
        </div>
    <?php endif; ?>

    <section class="stats">
        <div class="card">
            <span>Total Catatan Absensi</span>
            <strong><?= $totalCatatan ?></strong>
        </div>

        <div class="card">
            <span>Total Hadir</span>
            <strong><?= $totalHadir ?></strong>
        </div>

        <div class="card">
            <span>Total Izin</span>
            <strong><?= $totalIzin ?></strong>
        </div>

        <div class="card">
            <span>Total Sakit</span>
            <strong><?= $totalSakit ?></strong>
        </div>

        <div class="card">
            <span>Total Tidak Hadir</span>
            <strong><?= $totalTidakHadir ?></strong>
        </div>
    </section>

    <section class="filter-box">
        <h2>🔎 Filter Rekap Absensi</h2>

        <form method="GET" action="rekap_absensi.php">
            <div class="filter-grid">

                <div class="field">
                    <label for="kegiatan_id">Nama Kegiatan</label>

                    <select name="kegiatan_id" id="kegiatan_id">
                        <option value="0">Semua Kegiatan</option>

                        <?php foreach ($daftarKegiatan as $kegiatan): ?>
                            <option
                                value="<?= (int)$kegiatan['id'] ?>"
                                <?= $filterKegiatan === (int)$kegiatan['id']
                                    ? 'selected' : '' ?>
                            >
                                <?= h($kegiatan['nama_kegiatan']) ?>
                                -
                                <?= !empty($kegiatan['tanggal'])
                                    ? h(tanggalIndo($kegiatan['tanggal']))
                                    : 'Tanggal belum tersedia' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="field">
                    <label for="tanggal">Tanggal Kegiatan</label>

                    <input
                        type="date"
                        name="tanggal"
                        id="tanggal"
                        value="<?= h($filterTanggal) ?>"
                    >
                </div>

                <div class="field">
                    <label for="status">Status Kehadiran</label>

                    <select name="status" id="status">
                        <option value="">Semua Status</option>

                        <?php foreach ($statusValid as $pilihan): ?>
                            <option
                                value="<?= h($pilihan) ?>"
                                <?= $filterStatus === $pilihan
                                    ? 'selected' : '' ?>
                            >
                                <?= h($pilihan) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

            <div class="filter-actions">
                <button type="submit" class="btn btn-primary">
                    Tampilkan Rekap
                </button>

                <a href="rekap_absensi.php" class="btn btn-reset">
                    Reset Filter
                </a>
            </div>
        </form>
    </section>

    <section class="table-box">
        <h2>Rekap Detail Absensi</h2>

        <p class="subtitle">
            Tanggal kegiatan menunjukkan tanggal acara berlangsung.
            Tanggal input menunjukkan waktu data absensi terakhir
            tersimpan atau diperbarui.
        </p>

        <?php if ($error !== ''): ?>

            <div class="empty">
                Rekap belum dapat ditampilkan karena terjadi kesalahan.
            </div>

        <?php elseif (empty($rows)): ?>

            <div class="empty">
                Tidak ada data absensi yang sesuai dengan filter.
            </div>

        <?php else: ?>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Tanggal Kegiatan</th>
                            <th>Nama Kegiatan</th>
                            <th>Nama Anggota</th>
                            <th>Jabatan</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Tanggal Input Absensi</th>
                            <th>Terakhir Diperbarui</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($rows as $i => $row): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>

                                <td class="date-cell">
                                    <?= h(
                                        tanggalIndo(
                                            $row['tanggal_kegiatan']
                                        )
                                    ) ?>
                                </td>

                                <td>
                                    <?= h($row['nama_kegiatan']) ?>
                                </td>

                                <td>
                                    <?= h($row['nama']) ?>
                                </td>

                                <td>
                                    <?= h($row['jabatan']) ?>
                                </td>

                                <td>
                                    <span class="status <?= h(
                                        kelasStatus($row['status'])
                                    ) ?>">
                                        <?= h($row['status']) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= h(
                                        $row['keterangan'] ?: '-'
                                    ) ?>
                                </td>

                                <td class="date-cell">
                                    <?= h(
                                        tanggalWaktuIndo(
                                            $row['tanggal_input']
                                        )
                                    ) ?>
                                </td>

                                <td class="date-cell">
                                    <?= h(
                                        tanggalWaktuIndo(
                                            $row['updated_at']
                                        )
                                    ) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>
    </section>

</main>

<footer>
    Karang Taruna Lintang Sakti &copy; <?= date('Y') ?>
</footer>

</body>
</html>