<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include __DIR__ . '/../koneksi.php';

if (isset($_POST['simpan'])) {

    $nama = mysqli_real_escape_string(
        $koneksi,
        $_POST['nama_kegiatan']
    );

    $tanggal = $_POST['tanggal'];

    $lokasi = mysqli_real_escape_string(
        $koneksi,
        $_POST['lokasi']
    );

    $deskripsi = mysqli_real_escape_string(
        $koneksi,
        $_POST['deskripsi']
    );

    mysqli_query(
        $koneksi,
        "INSERT INTO kegiatan
        (nama_kegiatan, tanggal, lokasi, deskripsi)
        VALUES
        ('$nama', '$tanggal', '$lokasi', '$deskripsi')"
    );

    header("Location: kegiatan.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>Tambah Kegiatan</title>

    <link rel="stylesheet" href="../style.css">

</head>

<body>

<div class="container">

    <div class="form-box">

        <h2 class="judul">
            Tambah Kegiatan
        </h2>

        <form method="POST">

            <label>Nama Kegiatan</label>

            <input
                type="text"
                name="nama_kegiatan"
                required
            >

            <label>Tanggal</label>

            <input
                type="date"
                name="tanggal"
                required
            >

            <label>Lokasi</label>

            <input
                type="text"
                name="lokasi"
                required
            >

            <label>Deskripsi</label>

            <textarea
                name="deskripsi"
                rows="5"
            ></textarea>

            <button
                type="submit"
                name="simpan"
                class="btn"
            >
                Simpan
            </button>

            <a href="../admin/admin.php" class="btn">
                Kembali
            </a>

        </form>

    </div>

</div>

</body>

</html>