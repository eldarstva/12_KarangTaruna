<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include __DIR__ . '/../koneksi.php';

$id = $_GET['id'];

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM kegiatan WHERE id='$id'"
);

$data = mysqli_fetch_assoc($query);

if (isset($_POST['update'])) {

    $nama = mysqli_real_escape_string(
        $koneksi,
        $_POST['nama_kegiatan']
    );

    $tanggal = $_POST['tanggal'];

    $lokasi = mysqli_real_escape_string(
        $koneksi,
        $_POST['lokasi']
    );

    $deskripsi = mysqli_real_escape_string(
        $koneksi,
        $_POST['deskripsi']
    );

    mysqli_query(
        $koneksi,
        "UPDATE kegiatan SET
        nama_kegiatan='$nama',
        tanggal='$tanggal',
        lokasi='$lokasi',
        deskripsi='$deskripsi'
        WHERE id='$id'"
    );

    header("Location: kegiatan.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>Edit Kegiatan</title>

    <link rel="stylesheet" href="../style.css">

</head>

<body>

<div class="container">

    <div class="form-box">

        <h2 class="judul">
            Edit Kegiatan
        </h2>

        <form method="POST">

            <label>Nama Kegiatan</label>

            <input
                type="text"
                name="nama_kegiatan"
                value="<?= htmlspecialchars($data['nama_kegiatan']); ?>"
                required
            >

            <label>Tanggal</label>

            <input
                type="date"
                name="tanggal"
                value="<?= $data['tanggal']; ?>"
                required
            >

            <label>Lokasi</label>

            <input
                type="text"
                name="lokasi"
                value="<?= htmlspecialchars($data['lokasi']); ?>"
                required
            >

            <label>Deskripsi</label>

            <textarea
                name="deskripsi"
                rows="5"
            ><?= htmlspecialchars($data['deskripsi']); ?></textarea>

            <button
                type="submit"
                name="update"
                class="btn"
            >
                Update
            </button>

            <a href="kegiatan.php" class="btn">
                Kembali
            </a>

        </form>

    </div>

</div>

</body>

</html>