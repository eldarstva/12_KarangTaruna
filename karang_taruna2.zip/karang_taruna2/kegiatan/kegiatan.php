<?php
require_once __DIR__ . '/../koneksi.php';

// Halaman ini bisa dibuka pengunjung maupun pengguna yang sudah login.
$queryKegiatan = mysqli_query(
    $koneksi,
    "SELECT * FROM kegiatan ORDER BY tanggal DESC"
);

if (!$queryKegiatan) {
    die("Data kegiatan gagal dibaca. Periksa struktur tabel kegiatan di database.");
}

$role = $_SESSION['role'] ?? '';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kegiatan - Karang Taruna Lintang Sakti</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #fff7fa;
            color: #444;
        }

        nav {
            background: #e89ab2;
            padding: 18px 5%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 14px;
        }

        .logo {
            color: white;
            font-size: 21px;
            font-weight: bold;
            text-decoration: none;
        }

        .menu {
            display: flex;
            flex-wrap: wrap;
            gap: 18px;
        }

        .menu a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .menu a:hover {
            text-decoration: underline;
        }

        .judul {
            text-align: center;
            padding: 35px 20px 15px;
        }

        .judul h1 {
            color: #c96889;
            margin-bottom: 10px;
        }

        .daftar {
            padding: 25px 6% 45px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 20px;
        }

        .kartu {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 3px 12px #00000012;
            overflow-wrap: anywhere;
        }

        .kartu h2 {
            font-size: 19px;
            color: #c96889;
            margin-top: 0;
        }

        .tanggal {
            color: #8d6875;
            font-size: 14px;
            margin-bottom: 8px;
        }

        .lokasi {
            font-weight: bold;
            font-size: 14px;
        }

        .deskripsi {
            font-size: 14px;
            line-height: 1.7;
            white-space: pre-line;
        }

        .kosong {
            grid-column: 1 / -1;
            background: white;
            border-radius: 12px;
            padding: 30px;
            text-align: center;
        }

        .tombol {
            display: inline-block;
            padding: 10px 15px;
            margin-top: 10px;
            border-radius: 7px;
            background: #c96889;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        footer {
            background: #d77f9d;
            color: white;
            text-align: center;
            padding: 18px;
        }

        @media (max-width: 600px) {
            nav {
                justify-content: center;
            }

            .menu {
                justify-content: center;
                gap: 12px;
            }

            .judul h1 {
                font-size: 25px;
            }

            .daftar {
                padding: 20px 4% 35px;
            }
        }
    </style>
</head>

<body>

<nav>
    <a class="logo" href="../index.php">🌿 Karang Taruna</a>

    <div class="menu">
        <a href="../index.php">Beranda</a>
        <a href="../tentang.php">Profil</a>
        <a href="kegiatan.php">Kegiatan</a>
        <a href="../galeri/galeri.php">Galeri</a>

        <?php if ($role === 'admin'): ?>
            <a href="../admin/admin.php">Dashboard Admin</a>
            <a href="../logout.php">Logout</a>
        <?php elseif ($role === 'anggota'): ?>
            <a href="../anggota/anggota_dashboard.php">Dashboard Anggota</a>
            <a href="../logout.php">Logout</a>
        <?php else: ?>
            <a href="../login.php">Login</a>
        <?php endif; ?>
    </div>
</nav>

<header class="judul">
    <h1>Kegiatan Karang Taruna</h1>
    <p>Informasi kegiatan Karang Taruna Lintang Sakti.</p>

    <?php if ($role === 'admin'): ?>
        <a class="tombol" href="kegiatan_tambah.php">+ Tambah Kegiatan</a>
    <?php endif; ?>
</header>

<main class="daftar">

    <?php if (mysqli_num_rows($queryKegiatan) > 0): ?>

        <?php while ($data = mysqli_fetch_assoc($queryKegiatan)): ?>
            <article class="kartu">

                <h2>
                    <?= htmlspecialchars(
                        $data['nama_kegiatan'] ?? 'Kegiatan',
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </h2>

                <div class="tanggal">
                    Tanggal:
                    <?php
                    $tanggal = $data['tanggal'] ?? '';
                    if ($tanggal !== '' && strtotime($tanggal) !== false) {
                        echo htmlspecialchars(
                            date('d-m-Y', strtotime($tanggal)),
                            ENT_QUOTES,
                            'UTF-8'
                        );
                    } else {
                        echo '-';
                    }
                    ?>
                </div>

                <p class="lokasi">
                    Lokasi:
                    <?= htmlspecialchars(
                        $data['lokasi'] ?? '-',
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </p>

                <p class="deskripsi">
                    <?= htmlspecialchars(
                        $data['deskripsi'] ?? '',
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>
                </p>

                <?php if ($role === 'admin'): ?>
                    <a class="tombol"
                       href="kegiatan_edit.php?id=<?= (int)$data['id'] ?>">
                        Edit
                    </a>

                    <a class="tombol"
                       href="kegiatan_hapus.php?id=<?= (int)$data['id'] ?>"
                       onclick="return confirm('Yakin ingin menghapus kegiatan ini?')">
                        Hapus
                    </a>
                <?php endif; ?>

            </article>
        <?php endwhile; ?>

    <?php else: ?>

        <div class="kosong">
            <h2>Belum Ada Kegiatan</h2>
            <p>Data kegiatan akan muncul di halaman ini setelah ditambahkan.</p>
        </div>

    <?php endif; ?>

</main>

<footer>
    &copy; <?= date('Y') ?> Karang Taruna Lintang Sakti
</footer>

</body>
</html>
