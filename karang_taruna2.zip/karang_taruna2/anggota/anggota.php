<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include __DIR__ . '/../koneksi.php';

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM anggota ORDER BY id DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>Data Anggota</title>

    <link rel="stylesheet" href="../style.css">

</head>

<body>

<nav class="navbar">

    <a href="../admin/admin.php" class="logo">
        🌿 Admin Karang Taruna
    </a>

    <ul>

        <li>
            <a href="../admin/admin.php">
                Dashboard
            </a>
        </li>

        <li>
            <a href="../logout.php">
                Logout
            </a>
        </li>

    </ul>

</nav>

<div class="container">

    <h2 class="judul">
        Data Anggota
    </h2>

    <a href="anggota_tambah.php" class="btn">
        + Tambah Anggota
    </a>

    <br><br>

    <div class="table-box">

        <table>

            <tr>

                <th>No</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Jenis Kelamin</th>
                <th>Alamat</th>
                <th>No HP</th>
                <th>Aksi</th>

            </tr>

            <?php

            $no = 1;

            while ($data = mysqli_fetch_assoc($query)) {

            ?>

            <tr>

                <td><?= $no++; ?></td>

                <td><?= htmlspecialchars($data['nama']); ?></td>

                <td><?= htmlspecialchars($data['jabatan']); ?></td>

                <td><?= htmlspecialchars($data['jenis_kelamin']); ?></td>

                <td><?= htmlspecialchars($data['alamat']); ?></td>

                <td><?= htmlspecialchars($data['no_hp']); ?></td>

                <td>

                    <a
                        href="anggota_edit.php?id=<?= $data['id']; ?>"
                        class="btn btn-edit"
                    >
                        Edit
                    </a>

                    <a
                        href="anggota_hapus.php?id=<?= $data['id']; ?>"
                        class="btn btn-danger"
                        onclick="return confirm('Yakin ingin menghapus?')"
                    >
                        Hapus
                    </a>

                </td>

            </tr>

            <?php } ?>

        </table>

    </div>

</div>

</body>

</html>