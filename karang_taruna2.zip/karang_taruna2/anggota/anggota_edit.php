<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include __DIR__ . '/../koneksi.php';

$id = $_GET['id'];

$query = mysqli_query(
    $koneksi,
    "SELECT * FROM anggota WHERE id='$id'"
);

$data = mysqli_fetch_assoc($query);

if (isset($_POST['update'])) {

    $nama = mysqli_real_escape_string(
        $koneksi,
        $_POST['nama']
    );

    $jabatan = mysqli_real_escape_string(
        $koneksi,
        $_POST['jabatan']
    );

    $jenis_kelamin = $_POST['jenis_kelamin'];

    $alamat = mysqli_real_escape_string(
        $koneksi,
        $_POST['alamat']
    );

    $no_hp = mysqli_real_escape_string(
        $koneksi,
        $_POST['no_hp']
    );

    mysqli_query(
        $koneksi,
        "UPDATE anggota SET
        nama='$nama',
        jabatan='$jabatan',
        jenis_kelamin='$jenis_kelamin',
        alamat='$alamat',
        no_hp='$no_hp'
        WHERE id='$id'"
    );

    header("Location: anggota.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>Edit Anggota</title>

    <link rel="stylesheet" href="../style.css">

</head>

<body>

<div class="container">

    <div class="form-box">

        <h2 class="judul">
            Edit Anggota
        </h2>

        <form method="POST">

            <label>Nama</label>

            <input
                type="text"
                name="nama"
                value="<?= htmlspecialchars($data['nama']); ?>"
                required
            >

            <label>Jabatan</label>

            <input
                type="text"
                name="jabatan"
                value="<?= htmlspecialchars($data['jabatan']); ?>"
                required
            >

            <label>Jenis Kelamin</label>

            <select name="jenis_kelamin">

                <option
                    value="Laki-laki"
                    <?= $data['jenis_kelamin'] == 'Laki-laki' ? 'selected' : ''; ?>
                >
                    Laki-laki
                </option>

                <option
                    value="Perempuan"
                    <?= $data['jenis_kelamin'] == 'Perempuan' ? 'selected' : ''; ?>
                >
                    Perempuan
                </option>

            </select>

            <label>Alamat</label>

            <textarea
                name="alamat"
                rows="4"
            ><?= htmlspecialchars($data['alamat']); ?></textarea>

            <label>No HP</label>

            <input
                type="text"
                name="no_hp"
                value="<?= htmlspecialchars($data['no_hp']); ?>"
            >

            <button
                type="submit"
                name="update"
                class="btn"
            >
                Update
            </button>

            <a href="anggota.php" class="btn">
                Kembali
            </a>

        </form>

    </div>

</div>

</body>

</html>