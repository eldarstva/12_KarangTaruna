<?php

session_start();

if (!isset($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

include __DIR__ . '/../koneksi.php';

if (isset($_POST['simpan'])) {

    $nama = mysqli_real_escape_string(
        $koneksi,
        $_POST['nama']
    );

    $jabatan = mysqli_real_escape_string(
        $koneksi,
        $_POST['jabatan']
    );

    $jenis_kelamin = $_POST['jenis_kelamin'];

    $alamat = mysqli_real_escape_string(
        $koneksi,
        $_POST['alamat']
    );

    $no_hp = mysqli_real_escape_string(
        $koneksi,
        $_POST['no_hp']
    );

    mysqli_query(
        $koneksi,
        "INSERT INTO anggota
        (nama, jabatan, jenis_kelamin, alamat, no_hp)
        VALUES
        ('$nama', '$jabatan', '$jenis_kelamin', '$alamat', '$no_hp')"
    );

    header("Location: anggota.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <title>Tambah Anggota</title>

    <link rel="stylesheet" href="../style.css">

</head>

<body>

<div class="container">

    <div class="form-box">

        <h2 class="judul">
            Tambah Anggota
        </h2>

        <form method="POST">

            <label>Nama</label>

            <input
                type="text"
                name="nama"
                required
            >

            <label>Jabatan</label>

            <input
                type="text"
                name="jabatan"
                required
            >

            <label>Jenis Kelamin</label>

            <select name="jenis_kelamin" required>

                <option value="">
                    -- Pilih --
                </option>

                <option value="Laki-laki">
                    Laki-laki
                </option>

                <option value="Perempuan">
                    Perempuan
                </option>

            </select>

            <label>Alamat</label>

            <textarea
                name="alamat"
                rows="4"
            ></textarea>

            <label>No HP</label>

            <input
                type="text"
                name="no_hp"
            >

            <button
                type="submit"
                name="simpan"
                class="btn"
            >
                Simpan
            </button>

            <a href="anggota.php" class="btn">
                Kembali
            </a>

        </form>

    </div>

</div>

</body>

</html>