<?php
require_once __DIR__ . '/../koneksi.php';

/* CEK LOGIN */
if (empty($_SESSION['login'])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION['role'] ?? '') !== 'anggota') {
    if (($_SESSION['role'] ?? '') === 'admin') {
        header("Location: ../admin/admin.php");
    } else {
        header("Location: ../login.php");
    }
    exit;
}

/* TOTAL ANGGOTA */
$queryTotalAnggota = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total FROM anggota"
);

$totalAnggota = 0;

if ($queryTotalAnggota) {
    $dataTotalAnggota = mysqli_fetch_assoc($queryTotalAnggota);
    $totalAnggota = (int)($dataTotalAnggota['total'] ?? 0);
}

/* TOTAL KEGIATAN */
$queryTotalKegiatan = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total FROM kegiatan"
);

$totalKegiatan = 0;

if ($queryTotalKegiatan) {
    $dataTotalKegiatan = mysqli_fetch_assoc($queryTotalKegiatan);
    $totalKegiatan = (int)($dataTotalKegiatan['total'] ?? 0);
}

/* DAFTAR ANGGOTA */
$queryAnggota = mysqli_query(
    $koneksi,
    "SELECT * FROM anggota ORDER BY id DESC"
);

/* DAFTAR KEGIATAN */
$queryKegiatan = mysqli_query(
    $koneksi,
    "SELECT * FROM kegiatan ORDER BY tanggal DESC"
);

/* NAMA AKUN */
$username = $_SESSION['username'] ?? 'Anggota';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard Anggota - Karang Taruna Lintang Sakti</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #fff7fa;
            color: #555;
        }

        a {
            text-decoration: none;
        }

        /* SIDEBAR */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #e99ab3, #d987a5);
            padding: 25px 18px;
            color: white;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.08);
            overflow-y: auto;
            z-index: 10;
        }

        .logo {
            text-align: center;
            margin-bottom: 35px;
        }

        .logo .icon {
            font-size: 42px;
            margin-bottom: 5px;
        }

        .logo h2 {
            font-size: 20px;
        }

        .logo p {
            font-size: 12px;
            opacity: 0.9;
            margin-top: 5px;
        }

        .sidebar-menu {
            list-style: none;
        }

        .sidebar-menu li {
            margin-bottom: 10px;
        }

        .sidebar-menu a {
            display: block;
            padding: 13px 15px;
            border-radius: 10px;
            color: white;
            font-size: 14px;
            transition: 0.2s;
        }

        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255, 255, 255, 0.22);
        }

        .logout {
            margin-top: 35px;
        }

        .logout a {
            display: block;
            text-align: center;
            padding: 12px;
            background: white;
            color: #c76f89;
            border-radius: 9px;
            font-weight: bold;
            font-size: 14px;
        }

        /* KONTEN */
        .content {
            margin-left: 240px;
            padding: 30px;
            min-height: 100vh;
        }

        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }

        .welcome h1 {
            color: #bd708a;
            font-size: 28px;
            margin-bottom: 8px;
        }

        .welcome p {
            color: #777;
            font-size: 14px;
            line-height: 1.6;
        }

        .user-badge {
            background: white;
            padding: 12px 16px;
            border-radius: 25px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.07);
            color: #bd708a;
            font-size: 14px;
            font-weight: bold;
            overflow-wrap: anywhere;
        }

        /* KARTU STATISTIK */
        .stats {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            display: flex;
            align-items: center;
            gap: 18px;
            cursor: pointer;
            border: 2px solid transparent;
            box-shadow: 0 5px 18px rgba(0, 0, 0, 0.07);
            transition: 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            border-color: #e99ab3;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            flex-shrink: 0;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            background: #ffe5ed;
        }

        .stat-info h2 {
            font-size: 30px;
            color: #bd708a;
            margin-bottom: 5px;
        }

        .stat-info p {
            color: #777;
            font-size: 14px;
        }

        .click-text {
            margin-left: auto;
            color: #d889a0;
            font-size: 12px;
            text-align: right;
        }

        /* PANEL */
        .panel {
            display: none;
            background: white;
            border-radius: 15px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 5px 18px rgba(0, 0, 0, 0.07);
            scroll-margin-top: 20px;
        }

        .panel.show {
            display: block;
        }

        .panel-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
        }

        .panel-header h2 {
            color: #bd708a;
            font-size: 21px;
        }

        .tutup {
            border: none;
            background: #ffe5ed;
            color: #bd708a;
            padding: 9px 12px;
            border-radius: 7px;
            cursor: pointer;
            font-weight: bold;
        }

        /* TABEL ANGGOTA */
        .table-wrapper {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 400px;
        }

        table th {
            background: #e99ab3;
            color: white;
            padding: 12px;
            text-align: left;
            font-size: 14px;
        }

        table td {
            padding: 12px;
            border-bottom: 1px solid #f3dce3;
            font-size: 14px;
        }

        table tr:hover td {
            background: #fff7fa;
        }

        .badge {
            display: inline-block;
            background: #ffe5ed;
            color: #bd708a;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        /* DAFTAR KEGIATAN */
        .kegiatan-list {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 18px;
        }

        .kegiatan-card {
            border: 1px solid #f2dce3;
            border-radius: 12px;
            overflow: hidden;
            background: white;
            transition: 0.2s;
        }

        .kegiatan-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.08);
        }

        .no-image {
            height: 100px;
            background: #fff0f5;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #bd708a;
            font-size: 30px;
        }

        .kegiatan-info {
            padding: 15px;
        }

        .kegiatan-info h3 {
            color: #bd708a;
            font-size: 17px;
            margin-bottom: 10px;
            overflow-wrap: anywhere;
        }

        .kegiatan-info p {
            font-size: 13px;
            color: #666;
            margin-bottom: 7px;
            line-height: 1.6;
            overflow-wrap: anywhere;
        }

        .tombol-detail {
            display: inline-block;
            margin-top: 8px;
            background: #e99ab3;
            color: white;
            padding: 9px 12px;
            border-radius: 7px;
            font-size: 13px;
            font-weight: bold;
        }

        /* INFORMASI */
        .info-box {
            background: linear-gradient(135deg, white, #fff0f5);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 18px rgba(0, 0, 0, 0.06);
        }

        .info-box h2 {
            color: #bd708a;
            font-size: 20px;
            margin-bottom: 10px;
        }

        .info-box p {
            line-height: 1.8;
            font-size: 14px;
            color: #666;
        }

        .kosong {
            grid-column: 1 / -1;
            text-align: center;
            padding: 30px;
            color: #777;
            background: #fff7fa;
            border-radius: 10px;
        }

        footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #999;
            padding: 15px;
        }

        /* RESPONSIVE */
        @media (max-width: 900px) {
            .sidebar {
                width: 210px;
            }

            .content {
                margin-left: 210px;
                padding: 22px;
            }

            .stats {
                grid-template-columns: 1fr;
                gap: 15px;
            }

            .kegiatan-list {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 600px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
                padding: 20px;
            }

            .logo {
                margin-bottom: 20px;
            }

            .sidebar-menu {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 8px;
            }

            .sidebar-menu li {
                margin-bottom: 0;
            }

            .sidebar-menu a {
                padding: 11px 8px;
                text-align: center;
                font-size: 12px;
            }

            .logout {
                margin-top: 15px;
            }

            .content {
                margin-left: 0;
                padding: 18px;
            }

            .top-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .welcome h1 {
                font-size: 23px;
            }

            .stat-card {
                padding: 18px;
                gap: 12px;
            }

            .stat-icon {
                width: 50px;
                height: 50px;
                font-size: 23px;
            }

            .stat-info h2 {
                font-size: 25px;
            }

            .click-text {
                font-size: 11px;
            }

            .panel {
                padding: 16px;
            }

            .panel-header h2 {
                font-size: 17px;
            }
        }
    </style>
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar">

    <div class="logo">
        <div class="icon">🌸</div>
        <h2>Karang Taruna</h2>
        <p>Area Anggota</p>
    </div>

    <ul class="sidebar-menu">
        <li>
            <a href="anggota_dashboard.php" class="active">
                🏠 Dashboard
            </a>
        </li>

        <li>
            <a href="#panelAnggota" onclick="return bukaAnggota();">
                👥 Daftar Anggota
            </a>
        </li>

        <li>
            <a href="#panelKegiatan" onclick="return bukaKegiatan();">
                📅 Kegiatan
            </a>
        </li>

        <li>
            <a href="../absensi.php">
                ✅ Absensi Saya
            </a>
        </li>

        <li>
            <a href="../rekap_absensi.php">
                📊 Rekap Absensi
            </a>
        </li>

        <li>
            <a href="../index.php">
                🌸 Beranda Website
            </a>
        </li>

        <li>
            <a href="../galeri/galeri.php">
                🖼️ Galeri
            </a>
        </li>
    </ul>

    <div class="logout">
        <a href="../logout.php"
           onclick="return confirm('Yakin ingin logout?');">
            🚪 Logout
        </a>
    </div>

</aside>

<!-- KONTEN UTAMA -->
<main class="content">

    <div class="top-header">
        <div class="welcome">
            <h1>
                Halo,
                <?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>
                👋
            </h1>

            <p>
                Selamat datang di dashboard anggota Karang Taruna Lintang Sakti.
                Kamu dapat melihat informasi anggota dan kegiatan terbaru.
            </p>
        </div>

        <div class="user-badge">
            👤
            <?= htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>
        </div>
    </div>

    <!-- KARTU STATISTIK -->
    <div class="stats">

        <div class="stat-card" onclick="bukaAnggota();">
            <div class="stat-icon">👥</div>

            <div class="stat-info">
                <h2><?= $totalAnggota; ?></h2>
                <p>Total Anggota</p>
            </div>

            <div class="click-text">Lihat daftar →</div>
        </div>

        <div class="stat-card" onclick="bukaKegiatan();">
            <div class="stat-icon">📅</div>

            <div class="stat-info">
                <h2><?= $totalKegiatan; ?></h2>
                <p>Total Kegiatan</p>
            </div>

            <div class="click-text">Lihat kegiatan →</div>
        </div>

    </div>

    <!-- PANEL DAFTAR ANGGOTA -->
    <section id="panelAnggota" class="panel">

        <div class="panel-header">
            <h2>👥 Daftar Anggota Karang Taruna</h2>

            <button
                type="button"
                class="tutup"
                onclick="tutupSemua();"
            >
                ✕ Tutup
            </button>
        </div>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>

                <?php if ($queryAnggota && mysqli_num_rows($queryAnggota) > 0): ?>

                    <?php $no = 1; ?>

                    <?php while ($anggota = mysqli_fetch_assoc($queryAnggota)): ?>
                        <tr>
                            <td><?= $no++; ?></td>

                            <td>
                                <?= htmlspecialchars(
                                    $anggota['nama'] ?? '-',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </td>

                            <td>
                                <?= htmlspecialchars(
                                    $anggota['jabatan'] ?? 'Anggota',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </td>

                            <td>
                                <span class="badge">Terdaftar</span>
                            </td>
                        </tr>
                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="4" style="text-align:center;">
                            Belum ada data anggota.
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>
            </table>
        </div>

    </section>

    <!-- PANEL KEGIATAN: TANPA FOTO -->
    <section id="panelKegiatan" class="panel">

        <div class="panel-header">
            <h2>📅 Kegiatan Karang Taruna</h2>

            <button
                type="button"
                class="tutup"
                onclick="tutupSemua();"
            >
                ✕ Tutup
            </button>
        </div>

        <div class="kegiatan-list">

            <?php if ($queryKegiatan && mysqli_num_rows($queryKegiatan) > 0): ?>

                <?php while ($kegiatan = mysqli_fetch_assoc($queryKegiatan)): ?>

                    <?php
                    $namaKegiatan = $kegiatan['nama_kegiatan']
                        ?? 'Kegiatan Karang Taruna';

                    $tanggal = $kegiatan['tanggal'] ?? '';
                    $lokasi = $kegiatan['lokasi'] ?? '-';
                    $deskripsi = $kegiatan['deskripsi'] ?? '';

                    $tanggalTampil = '-';

                    if ($tanggal !== '' && strtotime($tanggal) !== false) {
                        $tanggalTampil = date(
                            'd-m-Y',
                            strtotime($tanggal)
                        );
                    }
                    ?>

                    <article class="kegiatan-card">

                        <!-- Ikon kalender, bukan foto -->
                        <div class="no-image">
                            📅
                        </div>

                        <div class="kegiatan-info">

                            <h3>
                                <?= htmlspecialchars(
                                    $namaKegiatan,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </h3>

                            <p>
                                📅 Tanggal:
                                <?= htmlspecialchars(
                                    $tanggalTampil,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </p>

                            <p>
                                📍 Lokasi:
                                <?= htmlspecialchars(
                                    $lokasi,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                            </p>

                            <?php if (trim($deskripsi) !== ''): ?>
                                <p>
                                    <?= nl2br(htmlspecialchars(
                                        $deskripsi,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    )); ?>
                                </p>
                            <?php endif; ?>

                            <a
                                href="../kegiatan/kegiatan.php"
                                class="tombol-detail"
                            >
                                Lihat Halaman Kegiatan
                            </a>

                        </div>

                    </article>

                <?php endwhile; ?>

            <?php else: ?>

                <div class="kosong">
                    <h3>📅 Belum Ada Kegiatan</h3>

                    <p>
                        Informasi kegiatan akan muncul setelah admin
                        menambahkan data.
                    </p>
                </div>

            <?php endif; ?>

        </div>

    </section>

    <!-- INFORMASI -->
    <div class="info-box">
        <h2>🌸 Selamat Datang di Area Anggota</h2>

        <p>
            Dashboard ini digunakan anggota untuk melihat data anggota,
            informasi kegiatan, dan membuka halaman absensi.
            Pengelolaan serta perubahan data organisasi dilakukan oleh admin.
            Jika ingin keluar dari akun, klik tombol Logout di menu sebelah kiri.
        </p>
    </div>

    <footer>
        &copy; <?= date('Y'); ?> Karang Taruna Lintang Sakti
    </footer>

</main>

<script>
    function tutupSemua() {
        document
            .getElementById('panelAnggota')
            .classList.remove('show');

        document
            .getElementById('panelKegiatan')
            .classList.remove('show');
    }

    function bukaAnggota() {
        const panelAnggota = document.getElementById('panelAnggota');
        const panelKegiatan = document.getElementById('panelKegiatan');

        panelKegiatan.classList.remove('show');
        panelAnggota.classList.add('show');

        panelAnggota.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });

        return false;
    }

    function bukaKegiatan() {
        const panelAnggota = document.getElementById('panelAnggota');
        const panelKegiatan = document.getElementById('panelKegiatan');

        panelAnggota.classList.remove('show');
        panelKegiatan.classList.add('show');

        panelKegiatan.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });

        return false;
    }
</script>

</body>
</html>
