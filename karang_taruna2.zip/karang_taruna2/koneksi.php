<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

mysqli_report(MYSQLI_REPORT_OFF);

$koneksi = mysqli_connect("localhost", "root", "", "karang_taruna");

if (!$koneksi) {
    die("Koneksi database gagal. Pastikan MySQL XAMPP aktif dan database karang_taruna tersedia.");
}

mysqli_set_charset($koneksi, "utf8mb4");

/*
 * Halaman yang hanya boleh dibuka admin.
 * Halaman login dan halaman publik tidak dimasukkan ke daftar ini.
 */
$halamanAdmin = [
    'admin/admin.php',
    'anggota/anggota.php',
    'anggota/anggota_tambah.php',
    'anggota/anggota_edit.php',
    'anggota/anggota_hapus.php',
    'kegiatan/kegiatan_tambah.php',
    'kegiatan/kegiatan_edit.php',
    'kegiatan/kegiatan_hapus.php',
    'galeri/galeri_tambah.php',
    'galeri/galeri_edit.php',
    'galeri/galeri_hapus.php'
];

$halamanSekarang = basename($_SERVER['PHP_SELF'] ?? '');

if (in_array($halamanSekarang, $halamanAdmin, true)) {
    if (
        empty($_SESSION['login']) ||
        ($_SESSION['role'] ?? '') !== 'admin'
    ) {
        header("Location: login.php");
        exit;
    }
}
?>