<?php

include __DIR__ . '/koneksi.php';

$username = "admin";
$password = password_hash("admin123", PASSWORD_DEFAULT);

$cek = mysqli_query(
    $koneksi,
    "SELECT * FROM admin WHERE username='$username'"
);

if (mysqli_num_rows($cek) > 0) {

    echo "Akun admin sudah ada.";

} else {

    $query = mysqli_query(
        $koneksi,
        "INSERT INTO admin (username, password)
         VALUES ('$username', '$password')"
    );

    if ($query) {
        echo "Admin berhasil dibuat.<br>";
        echo "Username: admin<br>";
        echo "Password: admin123";
    } else {
        echo "Gagal membuat admin.";
    }
}

?>